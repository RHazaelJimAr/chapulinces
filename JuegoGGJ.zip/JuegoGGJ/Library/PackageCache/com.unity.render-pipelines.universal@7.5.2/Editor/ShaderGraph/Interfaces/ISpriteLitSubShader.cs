using UnityEditor.ShaderGraph;

namespace UnityEditor.Experimental.Rendering.Universal
{
    interface ISpriteLitSubShader : ISubShader
    {}
}
