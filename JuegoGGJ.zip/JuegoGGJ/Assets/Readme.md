### Caracteristicas generales
Todo en unity en metros
de altura jugador mide 1.60 m