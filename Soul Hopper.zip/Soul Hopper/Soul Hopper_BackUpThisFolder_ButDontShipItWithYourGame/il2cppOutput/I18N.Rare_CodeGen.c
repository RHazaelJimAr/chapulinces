﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void I18N.Rare.CP1026::.ctor()
extern void CP1026__ctor_m39B1953FB2625E91E6381AA1C39B013BB3411263 (void);
// 0x00000002 System.Int32 I18N.Rare.CP1026::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1026_GetByteCountImpl_m4E5731B06379149E73C05821302B0E5CA41D4D3D (void);
// 0x00000003 System.Int32 I18N.Rare.CP1026::GetByteCount(System.String)
extern void CP1026_GetByteCount_mA340B3F82CE6626AF6DFE150858F29976AD775C8 (void);
// 0x00000004 System.Void I18N.Rare.CP1026::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1026_ToBytes_mC34DFFA061881B1802F58B1E80C79515B47FD000 (void);
// 0x00000005 System.Int32 I18N.Rare.CP1026::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1026_GetBytesImpl_m44AF3D36BC9B9994870750A460EC30F572BD33CD (void);
// 0x00000006 System.Void I18N.Rare.CP1026::.cctor()
extern void CP1026__cctor_m9569DEBC3422A371C46AB5FC16A9B6FE8C7767FF (void);
// 0x00000007 System.Void I18N.Rare.ENCibm1026::.ctor()
extern void ENCibm1026__ctor_mAD4D9249065E0A2717F50AB67829DFCBEA8428E1 (void);
// 0x00000008 System.Void I18N.Rare.CP1047::.ctor()
extern void CP1047__ctor_mA6B8BCD9AAB532982B0203A7EE620A2F8E3AD2EC (void);
// 0x00000009 System.Int32 I18N.Rare.CP1047::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1047_GetByteCountImpl_m8833AB893D1A82FBB0E1047B74E83196BC323B97 (void);
// 0x0000000A System.Int32 I18N.Rare.CP1047::GetByteCount(System.String)
extern void CP1047_GetByteCount_mD71280545EAE05F3D416B9461ED9F9864506AD9F (void);
// 0x0000000B System.Void I18N.Rare.CP1047::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1047_ToBytes_m5DCC6893ECC9F458F82DF9FF554CBA0C149D180F (void);
// 0x0000000C System.Int32 I18N.Rare.CP1047::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1047_GetBytesImpl_m98CE1CF8F4B3D43C8761311187A7E36C89F4F177 (void);
// 0x0000000D System.Void I18N.Rare.CP1047::.cctor()
extern void CP1047__cctor_m58FEA58F19D6A8DA48CCD10FDC307DBA2A59683D (void);
// 0x0000000E System.Void I18N.Rare.ENCibm1047::.ctor()
extern void ENCibm1047__ctor_mCAFD592FFE9519CAD8DE91632F3291ED4BB97504 (void);
// 0x0000000F System.Void I18N.Rare.CP1140::.ctor()
extern void CP1140__ctor_m2CF82CF29534CDADB54D19D0E05E2E699351442C (void);
// 0x00000010 System.Int32 I18N.Rare.CP1140::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1140_GetByteCountImpl_m4824B0E32EEF299929BC4191A12BF84E9FE1BBA2 (void);
// 0x00000011 System.Int32 I18N.Rare.CP1140::GetByteCount(System.String)
extern void CP1140_GetByteCount_m529A7B0534256082CB56456CDBEF5C7F5F8BB641 (void);
// 0x00000012 System.Void I18N.Rare.CP1140::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1140_ToBytes_m36749A8CB1078A14863792AC5FE6FFC34527F3FF (void);
// 0x00000013 System.Int32 I18N.Rare.CP1140::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1140_GetBytesImpl_m4DF6B0B3945750FD69987CE2C93D119FBBAE41CE (void);
// 0x00000014 System.Void I18N.Rare.CP1140::.cctor()
extern void CP1140__cctor_m7F7001EDD7329A8B636939A79B279DAEE204589A (void);
// 0x00000015 System.Void I18N.Rare.ENCibm01140::.ctor()
extern void ENCibm01140__ctor_m75FD0DC378EB5C3118FE4D36BC0A199C0598C571 (void);
// 0x00000016 System.Void I18N.Rare.CP1141::.ctor()
extern void CP1141__ctor_mB1C445162F8CF354ED7D56A02256B00AAEF9B086 (void);
// 0x00000017 System.Int32 I18N.Rare.CP1141::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1141_GetByteCountImpl_mE7A91B04EC87A6C831779CD719B9E262FBD8C6FE (void);
// 0x00000018 System.Int32 I18N.Rare.CP1141::GetByteCount(System.String)
extern void CP1141_GetByteCount_mD0D58668C8B9C7116D675A80327BC9AF60873225 (void);
// 0x00000019 System.Void I18N.Rare.CP1141::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1141_ToBytes_m8E6DCCAEA5223D6380CBB837B2E1FDD0814E5D75 (void);
// 0x0000001A System.Int32 I18N.Rare.CP1141::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1141_GetBytesImpl_m3FBAD858741A2998E3B8261050832C98F006B1ED (void);
// 0x0000001B System.Void I18N.Rare.CP1141::.cctor()
extern void CP1141__cctor_m1D197E091B4BA82D8F60641F6292D6854EBFADC2 (void);
// 0x0000001C System.Void I18N.Rare.ENCibm01141::.ctor()
extern void ENCibm01141__ctor_m2ACCC2A952ACE7E34C95328E64F8CF9A8C664E84 (void);
// 0x0000001D System.Void I18N.Rare.CP1142::.ctor()
extern void CP1142__ctor_mB83611C2A8A7DEB705C91635601D6821909183DE (void);
// 0x0000001E System.Int32 I18N.Rare.CP1142::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1142_GetByteCountImpl_m0F9F15125D9A8FEFBA2415367D02B987A2A8042B (void);
// 0x0000001F System.Int32 I18N.Rare.CP1142::GetByteCount(System.String)
extern void CP1142_GetByteCount_m0BA2038D4C2CFEF9F3AD9149C759253F4B0F585C (void);
// 0x00000020 System.Void I18N.Rare.CP1142::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1142_ToBytes_m53D14BA07F9ED5C25A6E6049C85B5BA9EBBEB33D (void);
// 0x00000021 System.Int32 I18N.Rare.CP1142::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1142_GetBytesImpl_m907BB5A927854A27288ACAB863A06AA165B6C83B (void);
// 0x00000022 System.Void I18N.Rare.CP1142::.cctor()
extern void CP1142__cctor_m677D581C1466A7152BAD9E2A7F06DF632724BFF1 (void);
// 0x00000023 System.Void I18N.Rare.ENCibm01142::.ctor()
extern void ENCibm01142__ctor_mD895439E8897B10D2DDC538A2BA34DEFB5A401BB (void);
// 0x00000024 System.Void I18N.Rare.CP1143::.ctor()
extern void CP1143__ctor_m545371431A8530853B25906A553A8E31E1805E20 (void);
// 0x00000025 System.Int32 I18N.Rare.CP1143::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1143_GetByteCountImpl_m8AB7E59CC2EC0B4EBE3F9494AA72B03CF582FE49 (void);
// 0x00000026 System.Int32 I18N.Rare.CP1143::GetByteCount(System.String)
extern void CP1143_GetByteCount_m9112759F87B423E3300769DFFD01F82677F230F7 (void);
// 0x00000027 System.Void I18N.Rare.CP1143::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1143_ToBytes_m0C06277A6BEE6F6BD81A67BC7F15621DF91E785D (void);
// 0x00000028 System.Int32 I18N.Rare.CP1143::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1143_GetBytesImpl_m52094E38DBDEF285AB2B42472445C3150A10542B (void);
// 0x00000029 System.Void I18N.Rare.CP1143::.cctor()
extern void CP1143__cctor_m7004EB0CFB5CAA631DE95541406665FEBBCD7D3B (void);
// 0x0000002A System.Void I18N.Rare.ENCibm01143::.ctor()
extern void ENCibm01143__ctor_m7B3553E21A8FE556078BAE6535D8110CCE411CC3 (void);
// 0x0000002B System.Void I18N.Rare.CP1144::.ctor()
extern void CP1144__ctor_m51B2788C88607B68EB56F8C483C43852806E2FEB (void);
// 0x0000002C System.Int32 I18N.Rare.CP1144::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1144_GetByteCountImpl_m7B04131E6283DEB9526BF24F11A8AE435943A876 (void);
// 0x0000002D System.Int32 I18N.Rare.CP1144::GetByteCount(System.String)
extern void CP1144_GetByteCount_m2DBD8E0EB1D938E23459EEEC807503F19DF4FD43 (void);
// 0x0000002E System.Void I18N.Rare.CP1144::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1144_ToBytes_mAE2A830C8FDDB4ED27A291286F8E4E4E754F26CA (void);
// 0x0000002F System.Int32 I18N.Rare.CP1144::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1144_GetBytesImpl_m60589C68F1629B5A90901840BEB5D25FA615B54D (void);
// 0x00000030 System.Void I18N.Rare.CP1144::.cctor()
extern void CP1144__cctor_mFC4EB2C8E73BBB0F3B316A1FB65393846B493CB5 (void);
// 0x00000031 System.Void I18N.Rare.ENCibm1144::.ctor()
extern void ENCibm1144__ctor_m52811A23199A731AFF90AB41A7576E27301B5107 (void);
// 0x00000032 System.Void I18N.Rare.CP1145::.ctor()
extern void CP1145__ctor_mAB2409045614A7F413331DD4038CC5613911051E (void);
// 0x00000033 System.Int32 I18N.Rare.CP1145::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1145_GetByteCountImpl_mCEC8661DBAD8D12C2401E0052D0E2B68343FB73E (void);
// 0x00000034 System.Int32 I18N.Rare.CP1145::GetByteCount(System.String)
extern void CP1145_GetByteCount_mE52D4854149C7F0BD7A3E901EEF647FE9C11BDEF (void);
// 0x00000035 System.Void I18N.Rare.CP1145::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1145_ToBytes_m9E4803110AA355E95163EDD3D47D974934010F23 (void);
// 0x00000036 System.Int32 I18N.Rare.CP1145::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1145_GetBytesImpl_mC943EC5EEEFF0E0DC594683F1E1BA4213BB691F3 (void);
// 0x00000037 System.Void I18N.Rare.CP1145::.cctor()
extern void CP1145__cctor_m0DD35CAC29800541FB762ABB301913DF3FAB80CB (void);
// 0x00000038 System.Void I18N.Rare.ENCibm1145::.ctor()
extern void ENCibm1145__ctor_m2B060BDA6F7C1075D7C32841F2ED05131EF6947E (void);
// 0x00000039 System.Void I18N.Rare.CP1146::.ctor()
extern void CP1146__ctor_m180465696E08BCB6EC33CC5D89EA23AFD199E9AF (void);
// 0x0000003A System.Int32 I18N.Rare.CP1146::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1146_GetByteCountImpl_m492DB1D83E7B599A5BA004DE5A774716A2A050DD (void);
// 0x0000003B System.Int32 I18N.Rare.CP1146::GetByteCount(System.String)
extern void CP1146_GetByteCount_m3E5A887651B37C4859EB33AD3354E7D5936B785C (void);
// 0x0000003C System.Void I18N.Rare.CP1146::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1146_ToBytes_mC4D3766DB5CB0023F19975E07A98A5B5E254D915 (void);
// 0x0000003D System.Int32 I18N.Rare.CP1146::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1146_GetBytesImpl_m41E4BCB7CB507C4703724177E1C80C5481584305 (void);
// 0x0000003E System.Void I18N.Rare.CP1146::.cctor()
extern void CP1146__cctor_m7462F6839B64FB3957D29B35647CF5250CE37796 (void);
// 0x0000003F System.Void I18N.Rare.ENCibm1146::.ctor()
extern void ENCibm1146__ctor_mC79A67B38A9D8AA85228D0442FC0CA5F3F9237C3 (void);
// 0x00000040 System.Void I18N.Rare.CP1147::.ctor()
extern void CP1147__ctor_mEA1FA288ECA6B5AB7FD835476B512A332855820A (void);
// 0x00000041 System.Int32 I18N.Rare.CP1147::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1147_GetByteCountImpl_mCDA649E61ABE9D9BA0A83F8E74CCD7A6B1352171 (void);
// 0x00000042 System.Int32 I18N.Rare.CP1147::GetByteCount(System.String)
extern void CP1147_GetByteCount_m041DDBF43D6AA3B57893B449FDB3B9AEEB6F9684 (void);
// 0x00000043 System.Void I18N.Rare.CP1147::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1147_ToBytes_m7670126FDB380C978676AC074FCC504CC033F1F8 (void);
// 0x00000044 System.Int32 I18N.Rare.CP1147::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1147_GetBytesImpl_mCBC1D40CAC99EED6898AE314C5184CF5386EBD77 (void);
// 0x00000045 System.Void I18N.Rare.CP1147::.cctor()
extern void CP1147__cctor_m31000FDB4D087E738E63F41E122EC261A7C290B1 (void);
// 0x00000046 System.Void I18N.Rare.ENCibm1147::.ctor()
extern void ENCibm1147__ctor_m026B64307429005248ACC79E7870717D278A6907 (void);
// 0x00000047 System.Void I18N.Rare.CP1148::.ctor()
extern void CP1148__ctor_mF566457669C1C945F3D0CA20E590D472E0EB31C1 (void);
// 0x00000048 System.Int32 I18N.Rare.CP1148::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1148_GetByteCountImpl_m331DD8AA6BC8D01732B10A560BB401BBB1D8A63A (void);
// 0x00000049 System.Int32 I18N.Rare.CP1148::GetByteCount(System.String)
extern void CP1148_GetByteCount_mDC00CEE7CD0148F4935597C3021D12C8414C4AA5 (void);
// 0x0000004A System.Void I18N.Rare.CP1148::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1148_ToBytes_m4BA3782920D586AF57BB117D2A9278CD6B5109A2 (void);
// 0x0000004B System.Int32 I18N.Rare.CP1148::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1148_GetBytesImpl_m7CDE958FCEF4A68852BC7D43E9B794A5AA15BB56 (void);
// 0x0000004C System.Void I18N.Rare.CP1148::.cctor()
extern void CP1148__cctor_m1FA8F131B4551B420CAAE83C3C1930653AE0D9A0 (void);
// 0x0000004D System.Void I18N.Rare.ENCibm1148::.ctor()
extern void ENCibm1148__ctor_m781E9BC274835D6A9185D867013CDEA2C6D466CA (void);
// 0x0000004E System.Void I18N.Rare.CP1149::.ctor()
extern void CP1149__ctor_m2411058354D619C2438CFDBD9F26E917C67F5AE0 (void);
// 0x0000004F System.Int32 I18N.Rare.CP1149::GetByteCountImpl(System.Char*,System.Int32)
extern void CP1149_GetByteCountImpl_m40B1EC72150DE57C232E729D21B6FE47617D57C0 (void);
// 0x00000050 System.Int32 I18N.Rare.CP1149::GetByteCount(System.String)
extern void CP1149_GetByteCount_m73A6DCF6BA504BD3749742F694CF6A991EA5DA1E (void);
// 0x00000051 System.Void I18N.Rare.CP1149::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1149_ToBytes_m8C8FDF2F2929724CF1DCBDDB88DE84B9BA56706D (void);
// 0x00000052 System.Int32 I18N.Rare.CP1149::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP1149_GetBytesImpl_m1A833A140E8745769F96025E48522B3A5F2DB3C1 (void);
// 0x00000053 System.Void I18N.Rare.CP1149::.cctor()
extern void CP1149__cctor_m415163D8C11131539873EA1CB5DC4FA8DE77D82C (void);
// 0x00000054 System.Void I18N.Rare.ENCibm1149::.ctor()
extern void ENCibm1149__ctor_m1FE6F1E6B60863BDF83E25CCE9B5CCF100BF14D3 (void);
// 0x00000055 System.Void I18N.Rare.CP20273::.ctor()
extern void CP20273__ctor_m6559CA3A7DEE00F239E661A35A5DA1900FAF29FF (void);
// 0x00000056 System.Int32 I18N.Rare.CP20273::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20273_GetByteCountImpl_mB8AD4A34B0C5CE30E35989FC6275A061B9DE6D8E (void);
// 0x00000057 System.Int32 I18N.Rare.CP20273::GetByteCount(System.String)
extern void CP20273_GetByteCount_mE8BC44BA2705257FEA6F922FB5DAF2CA8928B0F1 (void);
// 0x00000058 System.Void I18N.Rare.CP20273::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20273_ToBytes_m8148B170396AC003257738FE156D848412810C83 (void);
// 0x00000059 System.Int32 I18N.Rare.CP20273::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20273_GetBytesImpl_mCF577F077E513931FFCB81003AE9B75A82C9644A (void);
// 0x0000005A System.Void I18N.Rare.CP20273::.cctor()
extern void CP20273__cctor_mF4B56B301E66A12ACA4ABF9E8AB80289A5B6E27A (void);
// 0x0000005B System.Void I18N.Rare.ENCibm273::.ctor()
extern void ENCibm273__ctor_mC481535F1C4B88989D77E50D226516E1B4DD085C (void);
// 0x0000005C System.Void I18N.Rare.CP20277::.ctor()
extern void CP20277__ctor_m234EECF9D060901E2465A47D24581417981D2819 (void);
// 0x0000005D System.Int32 I18N.Rare.CP20277::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20277_GetByteCountImpl_mB1BEAC240D57C97F1BB5FAB3973CB63878879620 (void);
// 0x0000005E System.Int32 I18N.Rare.CP20277::GetByteCount(System.String)
extern void CP20277_GetByteCount_m07AB0AA9933B3A373F0EE6C844DCB7516C400F6B (void);
// 0x0000005F System.Void I18N.Rare.CP20277::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20277_ToBytes_m2DA3E113D1292DF63DEF4C4936C4768E51CCF557 (void);
// 0x00000060 System.Int32 I18N.Rare.CP20277::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20277_GetBytesImpl_m901169FA5999C79EFDDAFAF56749664D5B9F2EEC (void);
// 0x00000061 System.Void I18N.Rare.CP20277::.cctor()
extern void CP20277__cctor_m1F380BEF29D8521A094E2A2195A710C771B37F0C (void);
// 0x00000062 System.Void I18N.Rare.ENCibm277::.ctor()
extern void ENCibm277__ctor_mAC42A0A3E4D45A2ED5D7A2EE439F967DBEA40843 (void);
// 0x00000063 System.Void I18N.Rare.CP20278::.ctor()
extern void CP20278__ctor_mCFCECF0493A84404D5F887D19E220083588F99F0 (void);
// 0x00000064 System.Int32 I18N.Rare.CP20278::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20278_GetByteCountImpl_mB484C82A4F4CA395DE0D7B9B94C1545FEDA02850 (void);
// 0x00000065 System.Int32 I18N.Rare.CP20278::GetByteCount(System.String)
extern void CP20278_GetByteCount_mB7D657B371972770D0B88EF30A2002156A63F8AD (void);
// 0x00000066 System.Void I18N.Rare.CP20278::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20278_ToBytes_m6559CB941540C86D1D05911E6694BA62AF808002 (void);
// 0x00000067 System.Int32 I18N.Rare.CP20278::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20278_GetBytesImpl_m3B78D7BCFC9D7FCF65E6DF0CE58BFC066D4A7988 (void);
// 0x00000068 System.Void I18N.Rare.CP20278::.cctor()
extern void CP20278__cctor_m8B9C3A17DA0589E13278EDE475E6A67FF01A10B9 (void);
// 0x00000069 System.Void I18N.Rare.ENCibm278::.ctor()
extern void ENCibm278__ctor_m535D2A14A32ACD09EDA825C5AA3639705E14A09D (void);
// 0x0000006A System.Void I18N.Rare.CP20280::.ctor()
extern void CP20280__ctor_mE015898E516F59A3D99573EC8B8436E85F43F3F4 (void);
// 0x0000006B System.Int32 I18N.Rare.CP20280::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20280_GetByteCountImpl_m60A851531F730ED0306E0A551502234741F2D5F8 (void);
// 0x0000006C System.Int32 I18N.Rare.CP20280::GetByteCount(System.String)
extern void CP20280_GetByteCount_m2955BE690CFC8FF5BFE6D04E61DAEBEA857EFB2D (void);
// 0x0000006D System.Void I18N.Rare.CP20280::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20280_ToBytes_m987D00F80F50211115338A61B73892A05345CAAF (void);
// 0x0000006E System.Int32 I18N.Rare.CP20280::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20280_GetBytesImpl_m16306CBF2E6F98B96084EE67F81FDFCD2E599C5A (void);
// 0x0000006F System.Void I18N.Rare.CP20280::.cctor()
extern void CP20280__cctor_mE677987C75B371ABAF483119414A997AA78E467D (void);
// 0x00000070 System.Void I18N.Rare.ENCibm280::.ctor()
extern void ENCibm280__ctor_m1B6EB348E0332CC447278F7D40A74B7DEEE28975 (void);
// 0x00000071 System.Void I18N.Rare.CP20284::.ctor()
extern void CP20284__ctor_mBF1311D6DD9E8E15BD34892158610D296891F551 (void);
// 0x00000072 System.Int32 I18N.Rare.CP20284::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20284_GetByteCountImpl_mDC33D7EBF55925AEA146A2019F27E09C7855261C (void);
// 0x00000073 System.Int32 I18N.Rare.CP20284::GetByteCount(System.String)
extern void CP20284_GetByteCount_m44AF7871813CFA6AF4E3B9FAA9DE532961B694A9 (void);
// 0x00000074 System.Void I18N.Rare.CP20284::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20284_ToBytes_m5298BC2959C48F473862557E01E684AF65EDEACE (void);
// 0x00000075 System.Int32 I18N.Rare.CP20284::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20284_GetBytesImpl_m032024BF60E63DDF26287452F5C45B401E663F7C (void);
// 0x00000076 System.Void I18N.Rare.CP20284::.cctor()
extern void CP20284__cctor_m3B45FA12DE312C9CADAEAD8607501E7EE3F2E76D (void);
// 0x00000077 System.Void I18N.Rare.ENCibm284::.ctor()
extern void ENCibm284__ctor_m127A0BF9EA990286CA755D083D8183EAA736D5F0 (void);
// 0x00000078 System.Void I18N.Rare.CP20285::.ctor()
extern void CP20285__ctor_m569FEAE673839F59C3950E5327044F113371621F (void);
// 0x00000079 System.Int32 I18N.Rare.CP20285::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20285_GetByteCountImpl_m0145A8D3C9F3B2F78631A1C2C79CE062EEC6DB13 (void);
// 0x0000007A System.Int32 I18N.Rare.CP20285::GetByteCount(System.String)
extern void CP20285_GetByteCount_m2EB58DE4501F246C85C4BF32B72F9EB2909682B3 (void);
// 0x0000007B System.Void I18N.Rare.CP20285::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20285_ToBytes_m716478A1585F0DDCAC5FF49705F3A24F2A17F18A (void);
// 0x0000007C System.Int32 I18N.Rare.CP20285::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20285_GetBytesImpl_mF24B6481411012A59C5EF8165FED133D4D8B764F (void);
// 0x0000007D System.Void I18N.Rare.CP20285::.cctor()
extern void CP20285__cctor_mEF2F663E12D4A5477E3A92AF450158A264D2CBBD (void);
// 0x0000007E System.Void I18N.Rare.ENCibm285::.ctor()
extern void ENCibm285__ctor_m23D0D5059BC406AEA14D08A968A7126E809D48D0 (void);
// 0x0000007F System.Void I18N.Rare.CP20290::.ctor()
extern void CP20290__ctor_m8EC53F797E1B8E4C59A3CC60AA507C9F4199B487 (void);
// 0x00000080 System.Int32 I18N.Rare.CP20290::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20290_GetByteCountImpl_m1062AF52704D9E67122B15FA9F88D798B8801258 (void);
// 0x00000081 System.Int32 I18N.Rare.CP20290::GetByteCount(System.String)
extern void CP20290_GetByteCount_mC3C787090F0DB28DB6D463F3A068BE293E602625 (void);
// 0x00000082 System.Void I18N.Rare.CP20290::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20290_ToBytes_m059146E36AE044B0249C479B8FD99789D0A4B2DB (void);
// 0x00000083 System.Int32 I18N.Rare.CP20290::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20290_GetBytesImpl_m7FC4F785CCF72EA90FA56D7DBB86A7E424843760 (void);
// 0x00000084 System.Void I18N.Rare.CP20290::.cctor()
extern void CP20290__cctor_m23646414BEB727FE1E3009934D3C5A5BD4DA20D8 (void);
// 0x00000085 System.Void I18N.Rare.ENCibm290::.ctor()
extern void ENCibm290__ctor_mAAB1E1C9621A198612941F01642B14B3D17453AD (void);
// 0x00000086 System.Void I18N.Rare.CP20297::.ctor()
extern void CP20297__ctor_m7C942EC9517839A841C87D2412832EA89F7DB9ED (void);
// 0x00000087 System.Int32 I18N.Rare.CP20297::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20297_GetByteCountImpl_m97FA131F3EF9F405A4B84EB03FE8853A53103265 (void);
// 0x00000088 System.Int32 I18N.Rare.CP20297::GetByteCount(System.String)
extern void CP20297_GetByteCount_m846D641F809142F9E60D14A815F87B86AA72B0FC (void);
// 0x00000089 System.Void I18N.Rare.CP20297::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20297_ToBytes_m5B435BDCD5BA211019BBE22369C77CFD2F3BD55C (void);
// 0x0000008A System.Int32 I18N.Rare.CP20297::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20297_GetBytesImpl_m4E73B8C90D77D81BC63A171188011F29D229A490 (void);
// 0x0000008B System.Void I18N.Rare.CP20297::.cctor()
extern void CP20297__cctor_mD34CD69447B38FB41E1A6BE9DE9923EA911EF71C (void);
// 0x0000008C System.Void I18N.Rare.ENCibm297::.ctor()
extern void ENCibm297__ctor_m7A53C2A5B579B775088684602E48877781BA58F8 (void);
// 0x0000008D System.Void I18N.Rare.CP20420::.ctor()
extern void CP20420__ctor_mE1199075414679B6E9A75A5A0F276EF1B8F3E89F (void);
// 0x0000008E System.Int32 I18N.Rare.CP20420::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20420_GetByteCountImpl_m18FA19054EE4E4370EB539F9A1066A6D4B5EAC8D (void);
// 0x0000008F System.Int32 I18N.Rare.CP20420::GetByteCount(System.String)
extern void CP20420_GetByteCount_m5E195ED52B3336C62F3545E1D2F8C5D98FE49D8C (void);
// 0x00000090 System.Void I18N.Rare.CP20420::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20420_ToBytes_mDBA07E73492F3571A540EDB2E2830B054FE4190B (void);
// 0x00000091 System.Int32 I18N.Rare.CP20420::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20420_GetBytesImpl_mBBEA976A24251761A7027BEE914E4B5B1B8FF87B (void);
// 0x00000092 System.Void I18N.Rare.CP20420::.cctor()
extern void CP20420__cctor_m410575E8C107463593576EBB3BA005FA6D9E6A4E (void);
// 0x00000093 System.Void I18N.Rare.ENCibm420::.ctor()
extern void ENCibm420__ctor_mBF03FE908D50792A4131CBAD25E792AE86E650E0 (void);
// 0x00000094 System.Void I18N.Rare.CP20424::.ctor()
extern void CP20424__ctor_m1E85021A71B05CCBB2E6BFED9241C2E19CC1804B (void);
// 0x00000095 System.Int32 I18N.Rare.CP20424::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20424_GetByteCountImpl_m2BB1A847D4DCADCFFFB760EE27775CA9BF4600D3 (void);
// 0x00000096 System.Int32 I18N.Rare.CP20424::GetByteCount(System.String)
extern void CP20424_GetByteCount_m6AA933A082DAADE421BAC82232D7C4833A4F4C4B (void);
// 0x00000097 System.Void I18N.Rare.CP20424::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20424_ToBytes_mFE1CE27487D7D142CDA94BC35FDDA2A1DD2B3BF6 (void);
// 0x00000098 System.Int32 I18N.Rare.CP20424::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20424_GetBytesImpl_m571BCB7057F5A9A408FC9FC70033F7B3A62E59BD (void);
// 0x00000099 System.Void I18N.Rare.CP20424::.cctor()
extern void CP20424__cctor_m1FA346CADB4832707E5EE256B34AA9E6B02FE654 (void);
// 0x0000009A System.Void I18N.Rare.ENCibm424::.ctor()
extern void ENCibm424__ctor_m64BFF6216471E9D93A799AB23D834E3EB8AA14A3 (void);
// 0x0000009B System.Void I18N.Rare.CP20871::.ctor()
extern void CP20871__ctor_m2C9709576B96E37BDCD54AC0015ADEB27FCF2C7F (void);
// 0x0000009C System.Int32 I18N.Rare.CP20871::GetByteCountImpl(System.Char*,System.Int32)
extern void CP20871_GetByteCountImpl_m061918F6FB9D5FF279622DAE8C6235ADD7516B96 (void);
// 0x0000009D System.Int32 I18N.Rare.CP20871::GetByteCount(System.String)
extern void CP20871_GetByteCount_mCFE203D46DD8FA8DB3D87FA93A6F69E552EC9AAD (void);
// 0x0000009E System.Void I18N.Rare.CP20871::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20871_ToBytes_mDD83A5E662D13579D509F31390819353DCBA6132 (void);
// 0x0000009F System.Int32 I18N.Rare.CP20871::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP20871_GetBytesImpl_mC46E8A2AD9A16A0D7784495336B31F55B0494203 (void);
// 0x000000A0 System.Void I18N.Rare.CP20871::.cctor()
extern void CP20871__cctor_mD93BCAF84E781091B4EA9CFE99BF9DBFACA511E7 (void);
// 0x000000A1 System.Void I18N.Rare.ENCibm871::.ctor()
extern void ENCibm871__ctor_m6D6BC4C10F407AF2825D2E88CCEC2C5450F80743 (void);
// 0x000000A2 System.Void I18N.Rare.CP21025::.ctor()
extern void CP21025__ctor_m7991C64C9B7C6CBD2E9644E09BEBC382BF6EAA72 (void);
// 0x000000A3 System.Int32 I18N.Rare.CP21025::GetByteCountImpl(System.Char*,System.Int32)
extern void CP21025_GetByteCountImpl_m5B2B6C08F55C43CDE18910853837FDBB2CF5BCBF (void);
// 0x000000A4 System.Int32 I18N.Rare.CP21025::GetByteCount(System.String)
extern void CP21025_GetByteCount_mC5118AA109745C3D81D23976221CD213933E5F58 (void);
// 0x000000A5 System.Void I18N.Rare.CP21025::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP21025_ToBytes_mD06C5D425C78A3D85E8678A24BDFBF4628E965FA (void);
// 0x000000A6 System.Int32 I18N.Rare.CP21025::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP21025_GetBytesImpl_m6E8F0DCD5328761984E5FEB4880A1D9CB965AB7D (void);
// 0x000000A7 System.Void I18N.Rare.CP21025::.cctor()
extern void CP21025__cctor_m601615685F537065039C1DE5BDE553B22004213D (void);
// 0x000000A8 System.Void I18N.Rare.ENCibm1025::.ctor()
extern void ENCibm1025__ctor_mC40E6D2023E7781213354C21A4D62FF2069B2912 (void);
// 0x000000A9 System.Void I18N.Rare.CP37::.ctor()
extern void CP37__ctor_m980FA509A950BCB28807B6341B3EA7DCF0C88B09 (void);
// 0x000000AA System.Int32 I18N.Rare.CP37::GetByteCountImpl(System.Char*,System.Int32)
extern void CP37_GetByteCountImpl_m5E81968842DD9EDA5B655B9889FC1599FFF938C7 (void);
// 0x000000AB System.Int32 I18N.Rare.CP37::GetByteCount(System.String)
extern void CP37_GetByteCount_m6A65EA0E8E5975338A583624005647037152AD7C (void);
// 0x000000AC System.Void I18N.Rare.CP37::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP37_ToBytes_mE7E0AC40F6B4FFB0AC93C1196FEF4CFED556F451 (void);
// 0x000000AD System.Int32 I18N.Rare.CP37::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP37_GetBytesImpl_m3571BCAE36C4CFACF07858F58D13902DA814BD0E (void);
// 0x000000AE System.Void I18N.Rare.CP37::.cctor()
extern void CP37__cctor_mFE3E5DAF0ECE7BA7701868A4DA305F3FF90785CE (void);
// 0x000000AF System.Void I18N.Rare.ENCibm037::.ctor()
extern void ENCibm037__ctor_m5E42580ED4D04891457E342ED9C695A2A57EC4A8 (void);
// 0x000000B0 System.Void I18N.Rare.CP500::.ctor()
extern void CP500__ctor_mAAA34E6D6BE50CD4A4E5B549EC6E569D3DF3392B (void);
// 0x000000B1 System.Int32 I18N.Rare.CP500::GetByteCountImpl(System.Char*,System.Int32)
extern void CP500_GetByteCountImpl_m9801D5F51D055F027615B83955A5E7C6C13F4654 (void);
// 0x000000B2 System.Int32 I18N.Rare.CP500::GetByteCount(System.String)
extern void CP500_GetByteCount_m06B3FF5306E1506E5C1B3A31BE4B8C16C0F88189 (void);
// 0x000000B3 System.Void I18N.Rare.CP500::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP500_ToBytes_m363E2F897F3F9BC0779385F9305E809243BBE072 (void);
// 0x000000B4 System.Int32 I18N.Rare.CP500::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP500_GetBytesImpl_mB71D88579743CD47279E4DF343CEDB09BD6C7734 (void);
// 0x000000B5 System.Void I18N.Rare.CP500::.cctor()
extern void CP500__cctor_mC07A6DC1A725DB9DD8EDBD0E39710F64773347AA (void);
// 0x000000B6 System.Void I18N.Rare.ENCibm500::.ctor()
extern void ENCibm500__ctor_mE897F64AD305D7872AECAEA73CA8F91BEE80C0EF (void);
// 0x000000B7 System.Void I18N.Rare.CP708::.ctor()
extern void CP708__ctor_mDD6DF5663CDD3DFE9B6FB9CF07772F19861CBDDF (void);
// 0x000000B8 System.Int32 I18N.Rare.CP708::GetByteCountImpl(System.Char*,System.Int32)
extern void CP708_GetByteCountImpl_m0CCCDE6E604AD8268170708A107FB09D6E322F2F (void);
// 0x000000B9 System.Int32 I18N.Rare.CP708::GetByteCount(System.String)
extern void CP708_GetByteCount_m9FFFE8AC5951D2B0E3B02794B63BC6A5D3640F94 (void);
// 0x000000BA System.Void I18N.Rare.CP708::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP708_ToBytes_m12164204CED1ACA3FDCE64232F55DE8859461E4C (void);
// 0x000000BB System.Int32 I18N.Rare.CP708::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP708_GetBytesImpl_mAD2AE0DC992870FF549C8C59A923F57990D54FAD (void);
// 0x000000BC System.Void I18N.Rare.CP708::.cctor()
extern void CP708__cctor_m6C86FD3ABC1D1AAB279B22DD2F8DB4D49889427F (void);
// 0x000000BD System.Void I18N.Rare.ENCasmo_708::.ctor()
extern void ENCasmo_708__ctor_m02C750FD503B711433C5278D06FE4971E4CAE28C (void);
// 0x000000BE System.Void I18N.Rare.CP852::.ctor()
extern void CP852__ctor_m523BC32DFB989F14A7BD097A161C682C10FFB935 (void);
// 0x000000BF System.Int32 I18N.Rare.CP852::GetByteCountImpl(System.Char*,System.Int32)
extern void CP852_GetByteCountImpl_m6ED40106AD3074F24B58928AE4947C8EE7A21F2A (void);
// 0x000000C0 System.Int32 I18N.Rare.CP852::GetByteCount(System.String)
extern void CP852_GetByteCount_m9002C9545D03A1A194C6FA553AA02DDF85C01FB6 (void);
// 0x000000C1 System.Void I18N.Rare.CP852::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP852_ToBytes_mC92505D54077AA5AAEC639358DE313E287A6FA17 (void);
// 0x000000C2 System.Int32 I18N.Rare.CP852::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP852_GetBytesImpl_mD88A2E49D6D2D0D3075C7BB4353E1C9A128F4AC9 (void);
// 0x000000C3 System.Void I18N.Rare.CP852::.cctor()
extern void CP852__cctor_mD5A61BBFC9AC500FB4DD469C0A64174C23E1C28D (void);
// 0x000000C4 System.Void I18N.Rare.ENCibm852::.ctor()
extern void ENCibm852__ctor_mE01B95CECA6A8797015758FB20A7B3567840E716 (void);
// 0x000000C5 System.Void I18N.Rare.CP855::.ctor()
extern void CP855__ctor_mD906188E17E7B6B8BFFF378186BFB22118745725 (void);
// 0x000000C6 System.Int32 I18N.Rare.CP855::GetByteCountImpl(System.Char*,System.Int32)
extern void CP855_GetByteCountImpl_m61D4C37E98D15FD786A8C192BD7D2276E071D482 (void);
// 0x000000C7 System.Int32 I18N.Rare.CP855::GetByteCount(System.String)
extern void CP855_GetByteCount_m67A1E089C25811815795BF9F84A52549DEE5F64B (void);
// 0x000000C8 System.Void I18N.Rare.CP855::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP855_ToBytes_m72E7D755705CDFBE2EB2BAB3361D7A04C8B57A51 (void);
// 0x000000C9 System.Int32 I18N.Rare.CP855::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP855_GetBytesImpl_mA610F5B0A2B87EEA2FEC551B96067B26B2DADEC5 (void);
// 0x000000CA System.Void I18N.Rare.CP855::.cctor()
extern void CP855__cctor_mB9ACA367D1A3FC7264FA001D1DFD195E3754E634 (void);
// 0x000000CB System.Void I18N.Rare.ENCibm855::.ctor()
extern void ENCibm855__ctor_mC3AE426068AFBA7715EA6733CD2492D088786208 (void);
// 0x000000CC System.Void I18N.Rare.CP857::.ctor()
extern void CP857__ctor_m04B61ACEFC799F5F2954B626398DE8A12FD9A59D (void);
// 0x000000CD System.Int32 I18N.Rare.CP857::GetByteCountImpl(System.Char*,System.Int32)
extern void CP857_GetByteCountImpl_m46F07FCFDDEF5A2C31A7340CA70EBF11A8040E8A (void);
// 0x000000CE System.Int32 I18N.Rare.CP857::GetByteCount(System.String)
extern void CP857_GetByteCount_mB9E944ADC5E4C7617ADB8D3037041468914C52EB (void);
// 0x000000CF System.Void I18N.Rare.CP857::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP857_ToBytes_m8355DEBC4260E99C8ACA2228326EA9C572300232 (void);
// 0x000000D0 System.Int32 I18N.Rare.CP857::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP857_GetBytesImpl_m90349E78307F6186D1B7726FA5CBC4D1008576DB (void);
// 0x000000D1 System.Void I18N.Rare.CP857::.cctor()
extern void CP857__cctor_m42823BB500D19C758890A94293445FB689EF1AFA (void);
// 0x000000D2 System.Void I18N.Rare.ENCibm857::.ctor()
extern void ENCibm857__ctor_m451CBE46A1C2CB52AD057C8FD7D295E1FCB8EC6B (void);
// 0x000000D3 System.Void I18N.Rare.CP858::.ctor()
extern void CP858__ctor_m6236434507F11CBD528092D14C4D73D9BC495118 (void);
// 0x000000D4 System.Int32 I18N.Rare.CP858::GetByteCountImpl(System.Char*,System.Int32)
extern void CP858_GetByteCountImpl_m2750D6B4113AE523F8D3C8F9AB1EE023607D7153 (void);
// 0x000000D5 System.Int32 I18N.Rare.CP858::GetByteCount(System.String)
extern void CP858_GetByteCount_m61D0180026C88E0A2C91D9CAC39D7A565D0CC9E9 (void);
// 0x000000D6 System.Void I18N.Rare.CP858::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP858_ToBytes_mF56F8FB0F8D80D71EB731F270DDFF6916AE17424 (void);
// 0x000000D7 System.Int32 I18N.Rare.CP858::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP858_GetBytesImpl_m0E1204CB49BC34ACC848200F3E0F2BCD75EA9E50 (void);
// 0x000000D8 System.Void I18N.Rare.CP858::.cctor()
extern void CP858__cctor_mC2FA30FFDA59BAB09746D6BB19404A1CB471C150 (void);
// 0x000000D9 System.Void I18N.Rare.ENCibm00858::.ctor()
extern void ENCibm00858__ctor_m2FD1BF341BEDBAFF7D7B7CD84284BA8B4C498EC1 (void);
// 0x000000DA System.Void I18N.Rare.CP862::.ctor()
extern void CP862__ctor_m90FB9C114FD3C2A81B11A0A6CFB439FFD976795E (void);
// 0x000000DB System.Int32 I18N.Rare.CP862::GetByteCountImpl(System.Char*,System.Int32)
extern void CP862_GetByteCountImpl_m92A41C0AE3E4C18B4801C9976D104DEF26FB3F47 (void);
// 0x000000DC System.Int32 I18N.Rare.CP862::GetByteCount(System.String)
extern void CP862_GetByteCount_m03A02CB0135C7D4EE907D3AFC6129C79C3BA80FE (void);
// 0x000000DD System.Void I18N.Rare.CP862::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP862_ToBytes_m9DB1A883209CB8F54C8F12BAD5006D1FBB7DD703 (void);
// 0x000000DE System.Int32 I18N.Rare.CP862::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP862_GetBytesImpl_m665DEBD1FD33D1742A3E8F48091B245A8C463728 (void);
// 0x000000DF System.Void I18N.Rare.CP862::.cctor()
extern void CP862__cctor_mEFD64C6E41603900EC953A6946505C6FE23B521E (void);
// 0x000000E0 System.Void I18N.Rare.ENCibm862::.ctor()
extern void ENCibm862__ctor_m0B654C0254964E7C2A6DD70EEFCFE8BD6AB17238 (void);
// 0x000000E1 System.Void I18N.Rare.CP864::.ctor()
extern void CP864__ctor_m49B5EC32DBDCAF5A1A20C0684DF49E5DDABEB7CB (void);
// 0x000000E2 System.Int32 I18N.Rare.CP864::GetByteCountImpl(System.Char*,System.Int32)
extern void CP864_GetByteCountImpl_m42A05655BF2D003E9DBC5CBA2E3193E2C7973AC7 (void);
// 0x000000E3 System.Int32 I18N.Rare.CP864::GetByteCount(System.String)
extern void CP864_GetByteCount_mEA22FD4F46B3F63FC81DE91F04B610B8A5C42DE2 (void);
// 0x000000E4 System.Void I18N.Rare.CP864::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP864_ToBytes_m5C9EC8A6B95303EE436D71332663241306E345C0 (void);
// 0x000000E5 System.Int32 I18N.Rare.CP864::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP864_GetBytesImpl_m9E2B8B893697703D8E9D790BC1D76A73888E70F9 (void);
// 0x000000E6 System.Void I18N.Rare.CP864::.cctor()
extern void CP864__cctor_m3F8069AF7E1F25B8DE5CCD34BDE7E4F8D0FA4199 (void);
// 0x000000E7 System.Void I18N.Rare.ENCibm864::.ctor()
extern void ENCibm864__ctor_m6345E14B82B4D7C70468CD4D4958AF104573EA0F (void);
// 0x000000E8 System.Void I18N.Rare.CP866::.ctor()
extern void CP866__ctor_m3FCE35555BAA03D7C932FCBE2B79E91F284E63D5 (void);
// 0x000000E9 System.Int32 I18N.Rare.CP866::GetByteCountImpl(System.Char*,System.Int32)
extern void CP866_GetByteCountImpl_m176B37F94252AFDC3FF2862657A894CF42718CB2 (void);
// 0x000000EA System.Int32 I18N.Rare.CP866::GetByteCount(System.String)
extern void CP866_GetByteCount_mE74A1C2C3D2B390428B43F1D4BACAE99643674A6 (void);
// 0x000000EB System.Void I18N.Rare.CP866::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP866_ToBytes_m0C0361338706E3EEAE333CC0ADC20CF65B35682C (void);
// 0x000000EC System.Int32 I18N.Rare.CP866::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP866_GetBytesImpl_mFDEB4F5422083738D2598B0418E23557DAF003FF (void);
// 0x000000ED System.Void I18N.Rare.CP866::.cctor()
extern void CP866__cctor_mABDE7715DFCF25FD64FD5FA922D1488B0E4A0455 (void);
// 0x000000EE System.Void I18N.Rare.ENCibm866::.ctor()
extern void ENCibm866__ctor_m740C1295C12D74C2CFF3D522E09A3D0940E27B57 (void);
// 0x000000EF System.Void I18N.Rare.CP869::.ctor()
extern void CP869__ctor_mB2D20D1426BC17530CC5A564452AC737856A64BE (void);
// 0x000000F0 System.Int32 I18N.Rare.CP869::GetByteCountImpl(System.Char*,System.Int32)
extern void CP869_GetByteCountImpl_mACF222865A306F21391EF527DBE0B23BBE591504 (void);
// 0x000000F1 System.Int32 I18N.Rare.CP869::GetByteCount(System.String)
extern void CP869_GetByteCount_mE51A0171AEAA7A4C60AF938FC0797801A7131B10 (void);
// 0x000000F2 System.Void I18N.Rare.CP869::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP869_ToBytes_m908C126F3B43FB55E8BE2030D6CA0AC5F46E8C81 (void);
// 0x000000F3 System.Int32 I18N.Rare.CP869::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP869_GetBytesImpl_m483FA38EE3D6DE1B36CAE1268B7AB19647368553 (void);
// 0x000000F4 System.Void I18N.Rare.CP869::.cctor()
extern void CP869__cctor_m5D971D483561DD5ACE0E578D0F194BFA918D867C (void);
// 0x000000F5 System.Void I18N.Rare.ENCibm869::.ctor()
extern void ENCibm869__ctor_mB6D8CB4BD18CD116516A2D42DAB9D4B4024E07BC (void);
// 0x000000F6 System.Void I18N.Rare.CP870::.ctor()
extern void CP870__ctor_m507DDC6F8831E087004EB888A1C67143783ECBD0 (void);
// 0x000000F7 System.Int32 I18N.Rare.CP870::GetByteCountImpl(System.Char*,System.Int32)
extern void CP870_GetByteCountImpl_mEF3E403BEE9EC361073695E61A4CC48F75FAE416 (void);
// 0x000000F8 System.Int32 I18N.Rare.CP870::GetByteCount(System.String)
extern void CP870_GetByteCount_mEE46CEFC5C4CD808CF42FAE6F854D7B2A17B412B (void);
// 0x000000F9 System.Void I18N.Rare.CP870::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP870_ToBytes_m729E1F75CFE9A0A93D59FC3025634344DF75D19C (void);
// 0x000000FA System.Int32 I18N.Rare.CP870::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP870_GetBytesImpl_mA73798F83EA5920EE72D6591A6DF6BFAA3CD9186 (void);
// 0x000000FB System.Void I18N.Rare.CP870::.cctor()
extern void CP870__cctor_m421A99BF0940CDDC6B5E122D2E7A35DCFDCA5718 (void);
// 0x000000FC System.Void I18N.Rare.ENCibm870::.ctor()
extern void ENCibm870__ctor_m452D011942AFD0DAABDF9FAB0F4D4C36DD04F9FB (void);
// 0x000000FD System.Void I18N.Rare.CP875::.ctor()
extern void CP875__ctor_m6A44A19EAD24322D08698FC27A0B87FDC08CA459 (void);
// 0x000000FE System.Int32 I18N.Rare.CP875::GetByteCountImpl(System.Char*,System.Int32)
extern void CP875_GetByteCountImpl_m51CA9E517679109254D2D3A1D621BB9AE13AF6CE (void);
// 0x000000FF System.Int32 I18N.Rare.CP875::GetByteCount(System.String)
extern void CP875_GetByteCount_m16FE89DA644E0560CA567333DA197DEFE6F7D4AB (void);
// 0x00000100 System.Void I18N.Rare.CP875::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP875_ToBytes_m19DA22B375D56C6DBFEFBF1133BFECB5BD7C75D5 (void);
// 0x00000101 System.Int32 I18N.Rare.CP875::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void CP875_GetBytesImpl_m7B663B15464BE8503DE366D40C3D0BDF1404F001 (void);
// 0x00000102 System.Void I18N.Rare.CP875::.cctor()
extern void CP875__cctor_mD3FFDA27E8FDE077AF09C0DA00C23B97C750474F (void);
// 0x00000103 System.Void I18N.Rare.ENCibm875::.ctor()
extern void ENCibm875__ctor_m87AF81CCFD5FD3F8A05B8AAE05FAA3B3D84338CD (void);
static Il2CppMethodPointer s_methodPointers[259] = 
{
	CP1026__ctor_m39B1953FB2625E91E6381AA1C39B013BB3411263,
	CP1026_GetByteCountImpl_m4E5731B06379149E73C05821302B0E5CA41D4D3D,
	CP1026_GetByteCount_mA340B3F82CE6626AF6DFE150858F29976AD775C8,
	CP1026_ToBytes_mC34DFFA061881B1802F58B1E80C79515B47FD000,
	CP1026_GetBytesImpl_m44AF3D36BC9B9994870750A460EC30F572BD33CD,
	CP1026__cctor_m9569DEBC3422A371C46AB5FC16A9B6FE8C7767FF,
	ENCibm1026__ctor_mAD4D9249065E0A2717F50AB67829DFCBEA8428E1,
	CP1047__ctor_mA6B8BCD9AAB532982B0203A7EE620A2F8E3AD2EC,
	CP1047_GetByteCountImpl_m8833AB893D1A82FBB0E1047B74E83196BC323B97,
	CP1047_GetByteCount_mD71280545EAE05F3D416B9461ED9F9864506AD9F,
	CP1047_ToBytes_m5DCC6893ECC9F458F82DF9FF554CBA0C149D180F,
	CP1047_GetBytesImpl_m98CE1CF8F4B3D43C8761311187A7E36C89F4F177,
	CP1047__cctor_m58FEA58F19D6A8DA48CCD10FDC307DBA2A59683D,
	ENCibm1047__ctor_mCAFD592FFE9519CAD8DE91632F3291ED4BB97504,
	CP1140__ctor_m2CF82CF29534CDADB54D19D0E05E2E699351442C,
	CP1140_GetByteCountImpl_m4824B0E32EEF299929BC4191A12BF84E9FE1BBA2,
	CP1140_GetByteCount_m529A7B0534256082CB56456CDBEF5C7F5F8BB641,
	CP1140_ToBytes_m36749A8CB1078A14863792AC5FE6FFC34527F3FF,
	CP1140_GetBytesImpl_m4DF6B0B3945750FD69987CE2C93D119FBBAE41CE,
	CP1140__cctor_m7F7001EDD7329A8B636939A79B279DAEE204589A,
	ENCibm01140__ctor_m75FD0DC378EB5C3118FE4D36BC0A199C0598C571,
	CP1141__ctor_mB1C445162F8CF354ED7D56A02256B00AAEF9B086,
	CP1141_GetByteCountImpl_mE7A91B04EC87A6C831779CD719B9E262FBD8C6FE,
	CP1141_GetByteCount_mD0D58668C8B9C7116D675A80327BC9AF60873225,
	CP1141_ToBytes_m8E6DCCAEA5223D6380CBB837B2E1FDD0814E5D75,
	CP1141_GetBytesImpl_m3FBAD858741A2998E3B8261050832C98F006B1ED,
	CP1141__cctor_m1D197E091B4BA82D8F60641F6292D6854EBFADC2,
	ENCibm01141__ctor_m2ACCC2A952ACE7E34C95328E64F8CF9A8C664E84,
	CP1142__ctor_mB83611C2A8A7DEB705C91635601D6821909183DE,
	CP1142_GetByteCountImpl_m0F9F15125D9A8FEFBA2415367D02B987A2A8042B,
	CP1142_GetByteCount_m0BA2038D4C2CFEF9F3AD9149C759253F4B0F585C,
	CP1142_ToBytes_m53D14BA07F9ED5C25A6E6049C85B5BA9EBBEB33D,
	CP1142_GetBytesImpl_m907BB5A927854A27288ACAB863A06AA165B6C83B,
	CP1142__cctor_m677D581C1466A7152BAD9E2A7F06DF632724BFF1,
	ENCibm01142__ctor_mD895439E8897B10D2DDC538A2BA34DEFB5A401BB,
	CP1143__ctor_m545371431A8530853B25906A553A8E31E1805E20,
	CP1143_GetByteCountImpl_m8AB7E59CC2EC0B4EBE3F9494AA72B03CF582FE49,
	CP1143_GetByteCount_m9112759F87B423E3300769DFFD01F82677F230F7,
	CP1143_ToBytes_m0C06277A6BEE6F6BD81A67BC7F15621DF91E785D,
	CP1143_GetBytesImpl_m52094E38DBDEF285AB2B42472445C3150A10542B,
	CP1143__cctor_m7004EB0CFB5CAA631DE95541406665FEBBCD7D3B,
	ENCibm01143__ctor_m7B3553E21A8FE556078BAE6535D8110CCE411CC3,
	CP1144__ctor_m51B2788C88607B68EB56F8C483C43852806E2FEB,
	CP1144_GetByteCountImpl_m7B04131E6283DEB9526BF24F11A8AE435943A876,
	CP1144_GetByteCount_m2DBD8E0EB1D938E23459EEEC807503F19DF4FD43,
	CP1144_ToBytes_mAE2A830C8FDDB4ED27A291286F8E4E4E754F26CA,
	CP1144_GetBytesImpl_m60589C68F1629B5A90901840BEB5D25FA615B54D,
	CP1144__cctor_mFC4EB2C8E73BBB0F3B316A1FB65393846B493CB5,
	ENCibm1144__ctor_m52811A23199A731AFF90AB41A7576E27301B5107,
	CP1145__ctor_mAB2409045614A7F413331DD4038CC5613911051E,
	CP1145_GetByteCountImpl_mCEC8661DBAD8D12C2401E0052D0E2B68343FB73E,
	CP1145_GetByteCount_mE52D4854149C7F0BD7A3E901EEF647FE9C11BDEF,
	CP1145_ToBytes_m9E4803110AA355E95163EDD3D47D974934010F23,
	CP1145_GetBytesImpl_mC943EC5EEEFF0E0DC594683F1E1BA4213BB691F3,
	CP1145__cctor_m0DD35CAC29800541FB762ABB301913DF3FAB80CB,
	ENCibm1145__ctor_m2B060BDA6F7C1075D7C32841F2ED05131EF6947E,
	CP1146__ctor_m180465696E08BCB6EC33CC5D89EA23AFD199E9AF,
	CP1146_GetByteCountImpl_m492DB1D83E7B599A5BA004DE5A774716A2A050DD,
	CP1146_GetByteCount_m3E5A887651B37C4859EB33AD3354E7D5936B785C,
	CP1146_ToBytes_mC4D3766DB5CB0023F19975E07A98A5B5E254D915,
	CP1146_GetBytesImpl_m41E4BCB7CB507C4703724177E1C80C5481584305,
	CP1146__cctor_m7462F6839B64FB3957D29B35647CF5250CE37796,
	ENCibm1146__ctor_mC79A67B38A9D8AA85228D0442FC0CA5F3F9237C3,
	CP1147__ctor_mEA1FA288ECA6B5AB7FD835476B512A332855820A,
	CP1147_GetByteCountImpl_mCDA649E61ABE9D9BA0A83F8E74CCD7A6B1352171,
	CP1147_GetByteCount_m041DDBF43D6AA3B57893B449FDB3B9AEEB6F9684,
	CP1147_ToBytes_m7670126FDB380C978676AC074FCC504CC033F1F8,
	CP1147_GetBytesImpl_mCBC1D40CAC99EED6898AE314C5184CF5386EBD77,
	CP1147__cctor_m31000FDB4D087E738E63F41E122EC261A7C290B1,
	ENCibm1147__ctor_m026B64307429005248ACC79E7870717D278A6907,
	CP1148__ctor_mF566457669C1C945F3D0CA20E590D472E0EB31C1,
	CP1148_GetByteCountImpl_m331DD8AA6BC8D01732B10A560BB401BBB1D8A63A,
	CP1148_GetByteCount_mDC00CEE7CD0148F4935597C3021D12C8414C4AA5,
	CP1148_ToBytes_m4BA3782920D586AF57BB117D2A9278CD6B5109A2,
	CP1148_GetBytesImpl_m7CDE958FCEF4A68852BC7D43E9B794A5AA15BB56,
	CP1148__cctor_m1FA8F131B4551B420CAAE83C3C1930653AE0D9A0,
	ENCibm1148__ctor_m781E9BC274835D6A9185D867013CDEA2C6D466CA,
	CP1149__ctor_m2411058354D619C2438CFDBD9F26E917C67F5AE0,
	CP1149_GetByteCountImpl_m40B1EC72150DE57C232E729D21B6FE47617D57C0,
	CP1149_GetByteCount_m73A6DCF6BA504BD3749742F694CF6A991EA5DA1E,
	CP1149_ToBytes_m8C8FDF2F2929724CF1DCBDDB88DE84B9BA56706D,
	CP1149_GetBytesImpl_m1A833A140E8745769F96025E48522B3A5F2DB3C1,
	CP1149__cctor_m415163D8C11131539873EA1CB5DC4FA8DE77D82C,
	ENCibm1149__ctor_m1FE6F1E6B60863BDF83E25CCE9B5CCF100BF14D3,
	CP20273__ctor_m6559CA3A7DEE00F239E661A35A5DA1900FAF29FF,
	CP20273_GetByteCountImpl_mB8AD4A34B0C5CE30E35989FC6275A061B9DE6D8E,
	CP20273_GetByteCount_mE8BC44BA2705257FEA6F922FB5DAF2CA8928B0F1,
	CP20273_ToBytes_m8148B170396AC003257738FE156D848412810C83,
	CP20273_GetBytesImpl_mCF577F077E513931FFCB81003AE9B75A82C9644A,
	CP20273__cctor_mF4B56B301E66A12ACA4ABF9E8AB80289A5B6E27A,
	ENCibm273__ctor_mC481535F1C4B88989D77E50D226516E1B4DD085C,
	CP20277__ctor_m234EECF9D060901E2465A47D24581417981D2819,
	CP20277_GetByteCountImpl_mB1BEAC240D57C97F1BB5FAB3973CB63878879620,
	CP20277_GetByteCount_m07AB0AA9933B3A373F0EE6C844DCB7516C400F6B,
	CP20277_ToBytes_m2DA3E113D1292DF63DEF4C4936C4768E51CCF557,
	CP20277_GetBytesImpl_m901169FA5999C79EFDDAFAF56749664D5B9F2EEC,
	CP20277__cctor_m1F380BEF29D8521A094E2A2195A710C771B37F0C,
	ENCibm277__ctor_mAC42A0A3E4D45A2ED5D7A2EE439F967DBEA40843,
	CP20278__ctor_mCFCECF0493A84404D5F887D19E220083588F99F0,
	CP20278_GetByteCountImpl_mB484C82A4F4CA395DE0D7B9B94C1545FEDA02850,
	CP20278_GetByteCount_mB7D657B371972770D0B88EF30A2002156A63F8AD,
	CP20278_ToBytes_m6559CB941540C86D1D05911E6694BA62AF808002,
	CP20278_GetBytesImpl_m3B78D7BCFC9D7FCF65E6DF0CE58BFC066D4A7988,
	CP20278__cctor_m8B9C3A17DA0589E13278EDE475E6A67FF01A10B9,
	ENCibm278__ctor_m535D2A14A32ACD09EDA825C5AA3639705E14A09D,
	CP20280__ctor_mE015898E516F59A3D99573EC8B8436E85F43F3F4,
	CP20280_GetByteCountImpl_m60A851531F730ED0306E0A551502234741F2D5F8,
	CP20280_GetByteCount_m2955BE690CFC8FF5BFE6D04E61DAEBEA857EFB2D,
	CP20280_ToBytes_m987D00F80F50211115338A61B73892A05345CAAF,
	CP20280_GetBytesImpl_m16306CBF2E6F98B96084EE67F81FDFCD2E599C5A,
	CP20280__cctor_mE677987C75B371ABAF483119414A997AA78E467D,
	ENCibm280__ctor_m1B6EB348E0332CC447278F7D40A74B7DEEE28975,
	CP20284__ctor_mBF1311D6DD9E8E15BD34892158610D296891F551,
	CP20284_GetByteCountImpl_mDC33D7EBF55925AEA146A2019F27E09C7855261C,
	CP20284_GetByteCount_m44AF7871813CFA6AF4E3B9FAA9DE532961B694A9,
	CP20284_ToBytes_m5298BC2959C48F473862557E01E684AF65EDEACE,
	CP20284_GetBytesImpl_m032024BF60E63DDF26287452F5C45B401E663F7C,
	CP20284__cctor_m3B45FA12DE312C9CADAEAD8607501E7EE3F2E76D,
	ENCibm284__ctor_m127A0BF9EA990286CA755D083D8183EAA736D5F0,
	CP20285__ctor_m569FEAE673839F59C3950E5327044F113371621F,
	CP20285_GetByteCountImpl_m0145A8D3C9F3B2F78631A1C2C79CE062EEC6DB13,
	CP20285_GetByteCount_m2EB58DE4501F246C85C4BF32B72F9EB2909682B3,
	CP20285_ToBytes_m716478A1585F0DDCAC5FF49705F3A24F2A17F18A,
	CP20285_GetBytesImpl_mF24B6481411012A59C5EF8165FED133D4D8B764F,
	CP20285__cctor_mEF2F663E12D4A5477E3A92AF450158A264D2CBBD,
	ENCibm285__ctor_m23D0D5059BC406AEA14D08A968A7126E809D48D0,
	CP20290__ctor_m8EC53F797E1B8E4C59A3CC60AA507C9F4199B487,
	CP20290_GetByteCountImpl_m1062AF52704D9E67122B15FA9F88D798B8801258,
	CP20290_GetByteCount_mC3C787090F0DB28DB6D463F3A068BE293E602625,
	CP20290_ToBytes_m059146E36AE044B0249C479B8FD99789D0A4B2DB,
	CP20290_GetBytesImpl_m7FC4F785CCF72EA90FA56D7DBB86A7E424843760,
	CP20290__cctor_m23646414BEB727FE1E3009934D3C5A5BD4DA20D8,
	ENCibm290__ctor_mAAB1E1C9621A198612941F01642B14B3D17453AD,
	CP20297__ctor_m7C942EC9517839A841C87D2412832EA89F7DB9ED,
	CP20297_GetByteCountImpl_m97FA131F3EF9F405A4B84EB03FE8853A53103265,
	CP20297_GetByteCount_m846D641F809142F9E60D14A815F87B86AA72B0FC,
	CP20297_ToBytes_m5B435BDCD5BA211019BBE22369C77CFD2F3BD55C,
	CP20297_GetBytesImpl_m4E73B8C90D77D81BC63A171188011F29D229A490,
	CP20297__cctor_mD34CD69447B38FB41E1A6BE9DE9923EA911EF71C,
	ENCibm297__ctor_m7A53C2A5B579B775088684602E48877781BA58F8,
	CP20420__ctor_mE1199075414679B6E9A75A5A0F276EF1B8F3E89F,
	CP20420_GetByteCountImpl_m18FA19054EE4E4370EB539F9A1066A6D4B5EAC8D,
	CP20420_GetByteCount_m5E195ED52B3336C62F3545E1D2F8C5D98FE49D8C,
	CP20420_ToBytes_mDBA07E73492F3571A540EDB2E2830B054FE4190B,
	CP20420_GetBytesImpl_mBBEA976A24251761A7027BEE914E4B5B1B8FF87B,
	CP20420__cctor_m410575E8C107463593576EBB3BA005FA6D9E6A4E,
	ENCibm420__ctor_mBF03FE908D50792A4131CBAD25E792AE86E650E0,
	CP20424__ctor_m1E85021A71B05CCBB2E6BFED9241C2E19CC1804B,
	CP20424_GetByteCountImpl_m2BB1A847D4DCADCFFFB760EE27775CA9BF4600D3,
	CP20424_GetByteCount_m6AA933A082DAADE421BAC82232D7C4833A4F4C4B,
	CP20424_ToBytes_mFE1CE27487D7D142CDA94BC35FDDA2A1DD2B3BF6,
	CP20424_GetBytesImpl_m571BCB7057F5A9A408FC9FC70033F7B3A62E59BD,
	CP20424__cctor_m1FA346CADB4832707E5EE256B34AA9E6B02FE654,
	ENCibm424__ctor_m64BFF6216471E9D93A799AB23D834E3EB8AA14A3,
	CP20871__ctor_m2C9709576B96E37BDCD54AC0015ADEB27FCF2C7F,
	CP20871_GetByteCountImpl_m061918F6FB9D5FF279622DAE8C6235ADD7516B96,
	CP20871_GetByteCount_mCFE203D46DD8FA8DB3D87FA93A6F69E552EC9AAD,
	CP20871_ToBytes_mDD83A5E662D13579D509F31390819353DCBA6132,
	CP20871_GetBytesImpl_mC46E8A2AD9A16A0D7784495336B31F55B0494203,
	CP20871__cctor_mD93BCAF84E781091B4EA9CFE99BF9DBFACA511E7,
	ENCibm871__ctor_m6D6BC4C10F407AF2825D2E88CCEC2C5450F80743,
	CP21025__ctor_m7991C64C9B7C6CBD2E9644E09BEBC382BF6EAA72,
	CP21025_GetByteCountImpl_m5B2B6C08F55C43CDE18910853837FDBB2CF5BCBF,
	CP21025_GetByteCount_mC5118AA109745C3D81D23976221CD213933E5F58,
	CP21025_ToBytes_mD06C5D425C78A3D85E8678A24BDFBF4628E965FA,
	CP21025_GetBytesImpl_m6E8F0DCD5328761984E5FEB4880A1D9CB965AB7D,
	CP21025__cctor_m601615685F537065039C1DE5BDE553B22004213D,
	ENCibm1025__ctor_mC40E6D2023E7781213354C21A4D62FF2069B2912,
	CP37__ctor_m980FA509A950BCB28807B6341B3EA7DCF0C88B09,
	CP37_GetByteCountImpl_m5E81968842DD9EDA5B655B9889FC1599FFF938C7,
	CP37_GetByteCount_m6A65EA0E8E5975338A583624005647037152AD7C,
	CP37_ToBytes_mE7E0AC40F6B4FFB0AC93C1196FEF4CFED556F451,
	CP37_GetBytesImpl_m3571BCAE36C4CFACF07858F58D13902DA814BD0E,
	CP37__cctor_mFE3E5DAF0ECE7BA7701868A4DA305F3FF90785CE,
	ENCibm037__ctor_m5E42580ED4D04891457E342ED9C695A2A57EC4A8,
	CP500__ctor_mAAA34E6D6BE50CD4A4E5B549EC6E569D3DF3392B,
	CP500_GetByteCountImpl_m9801D5F51D055F027615B83955A5E7C6C13F4654,
	CP500_GetByteCount_m06B3FF5306E1506E5C1B3A31BE4B8C16C0F88189,
	CP500_ToBytes_m363E2F897F3F9BC0779385F9305E809243BBE072,
	CP500_GetBytesImpl_mB71D88579743CD47279E4DF343CEDB09BD6C7734,
	CP500__cctor_mC07A6DC1A725DB9DD8EDBD0E39710F64773347AA,
	ENCibm500__ctor_mE897F64AD305D7872AECAEA73CA8F91BEE80C0EF,
	CP708__ctor_mDD6DF5663CDD3DFE9B6FB9CF07772F19861CBDDF,
	CP708_GetByteCountImpl_m0CCCDE6E604AD8268170708A107FB09D6E322F2F,
	CP708_GetByteCount_m9FFFE8AC5951D2B0E3B02794B63BC6A5D3640F94,
	CP708_ToBytes_m12164204CED1ACA3FDCE64232F55DE8859461E4C,
	CP708_GetBytesImpl_mAD2AE0DC992870FF549C8C59A923F57990D54FAD,
	CP708__cctor_m6C86FD3ABC1D1AAB279B22DD2F8DB4D49889427F,
	ENCasmo_708__ctor_m02C750FD503B711433C5278D06FE4971E4CAE28C,
	CP852__ctor_m523BC32DFB989F14A7BD097A161C682C10FFB935,
	CP852_GetByteCountImpl_m6ED40106AD3074F24B58928AE4947C8EE7A21F2A,
	CP852_GetByteCount_m9002C9545D03A1A194C6FA553AA02DDF85C01FB6,
	CP852_ToBytes_mC92505D54077AA5AAEC639358DE313E287A6FA17,
	CP852_GetBytesImpl_mD88A2E49D6D2D0D3075C7BB4353E1C9A128F4AC9,
	CP852__cctor_mD5A61BBFC9AC500FB4DD469C0A64174C23E1C28D,
	ENCibm852__ctor_mE01B95CECA6A8797015758FB20A7B3567840E716,
	CP855__ctor_mD906188E17E7B6B8BFFF378186BFB22118745725,
	CP855_GetByteCountImpl_m61D4C37E98D15FD786A8C192BD7D2276E071D482,
	CP855_GetByteCount_m67A1E089C25811815795BF9F84A52549DEE5F64B,
	CP855_ToBytes_m72E7D755705CDFBE2EB2BAB3361D7A04C8B57A51,
	CP855_GetBytesImpl_mA610F5B0A2B87EEA2FEC551B96067B26B2DADEC5,
	CP855__cctor_mB9ACA367D1A3FC7264FA001D1DFD195E3754E634,
	ENCibm855__ctor_mC3AE426068AFBA7715EA6733CD2492D088786208,
	CP857__ctor_m04B61ACEFC799F5F2954B626398DE8A12FD9A59D,
	CP857_GetByteCountImpl_m46F07FCFDDEF5A2C31A7340CA70EBF11A8040E8A,
	CP857_GetByteCount_mB9E944ADC5E4C7617ADB8D3037041468914C52EB,
	CP857_ToBytes_m8355DEBC4260E99C8ACA2228326EA9C572300232,
	CP857_GetBytesImpl_m90349E78307F6186D1B7726FA5CBC4D1008576DB,
	CP857__cctor_m42823BB500D19C758890A94293445FB689EF1AFA,
	ENCibm857__ctor_m451CBE46A1C2CB52AD057C8FD7D295E1FCB8EC6B,
	CP858__ctor_m6236434507F11CBD528092D14C4D73D9BC495118,
	CP858_GetByteCountImpl_m2750D6B4113AE523F8D3C8F9AB1EE023607D7153,
	CP858_GetByteCount_m61D0180026C88E0A2C91D9CAC39D7A565D0CC9E9,
	CP858_ToBytes_mF56F8FB0F8D80D71EB731F270DDFF6916AE17424,
	CP858_GetBytesImpl_m0E1204CB49BC34ACC848200F3E0F2BCD75EA9E50,
	CP858__cctor_mC2FA30FFDA59BAB09746D6BB19404A1CB471C150,
	ENCibm00858__ctor_m2FD1BF341BEDBAFF7D7B7CD84284BA8B4C498EC1,
	CP862__ctor_m90FB9C114FD3C2A81B11A0A6CFB439FFD976795E,
	CP862_GetByteCountImpl_m92A41C0AE3E4C18B4801C9976D104DEF26FB3F47,
	CP862_GetByteCount_m03A02CB0135C7D4EE907D3AFC6129C79C3BA80FE,
	CP862_ToBytes_m9DB1A883209CB8F54C8F12BAD5006D1FBB7DD703,
	CP862_GetBytesImpl_m665DEBD1FD33D1742A3E8F48091B245A8C463728,
	CP862__cctor_mEFD64C6E41603900EC953A6946505C6FE23B521E,
	ENCibm862__ctor_m0B654C0254964E7C2A6DD70EEFCFE8BD6AB17238,
	CP864__ctor_m49B5EC32DBDCAF5A1A20C0684DF49E5DDABEB7CB,
	CP864_GetByteCountImpl_m42A05655BF2D003E9DBC5CBA2E3193E2C7973AC7,
	CP864_GetByteCount_mEA22FD4F46B3F63FC81DE91F04B610B8A5C42DE2,
	CP864_ToBytes_m5C9EC8A6B95303EE436D71332663241306E345C0,
	CP864_GetBytesImpl_m9E2B8B893697703D8E9D790BC1D76A73888E70F9,
	CP864__cctor_m3F8069AF7E1F25B8DE5CCD34BDE7E4F8D0FA4199,
	ENCibm864__ctor_m6345E14B82B4D7C70468CD4D4958AF104573EA0F,
	CP866__ctor_m3FCE35555BAA03D7C932FCBE2B79E91F284E63D5,
	CP866_GetByteCountImpl_m176B37F94252AFDC3FF2862657A894CF42718CB2,
	CP866_GetByteCount_mE74A1C2C3D2B390428B43F1D4BACAE99643674A6,
	CP866_ToBytes_m0C0361338706E3EEAE333CC0ADC20CF65B35682C,
	CP866_GetBytesImpl_mFDEB4F5422083738D2598B0418E23557DAF003FF,
	CP866__cctor_mABDE7715DFCF25FD64FD5FA922D1488B0E4A0455,
	ENCibm866__ctor_m740C1295C12D74C2CFF3D522E09A3D0940E27B57,
	CP869__ctor_mB2D20D1426BC17530CC5A564452AC737856A64BE,
	CP869_GetByteCountImpl_mACF222865A306F21391EF527DBE0B23BBE591504,
	CP869_GetByteCount_mE51A0171AEAA7A4C60AF938FC0797801A7131B10,
	CP869_ToBytes_m908C126F3B43FB55E8BE2030D6CA0AC5F46E8C81,
	CP869_GetBytesImpl_m483FA38EE3D6DE1B36CAE1268B7AB19647368553,
	CP869__cctor_m5D971D483561DD5ACE0E578D0F194BFA918D867C,
	ENCibm869__ctor_mB6D8CB4BD18CD116516A2D42DAB9D4B4024E07BC,
	CP870__ctor_m507DDC6F8831E087004EB888A1C67143783ECBD0,
	CP870_GetByteCountImpl_mEF3E403BEE9EC361073695E61A4CC48F75FAE416,
	CP870_GetByteCount_mEE46CEFC5C4CD808CF42FAE6F854D7B2A17B412B,
	CP870_ToBytes_m729E1F75CFE9A0A93D59FC3025634344DF75D19C,
	CP870_GetBytesImpl_mA73798F83EA5920EE72D6591A6DF6BFAA3CD9186,
	CP870__cctor_m421A99BF0940CDDC6B5E122D2E7A35DCFDCA5718,
	ENCibm870__ctor_m452D011942AFD0DAABDF9FAB0F4D4C36DD04F9FB,
	CP875__ctor_m6A44A19EAD24322D08698FC27A0B87FDC08CA459,
	CP875_GetByteCountImpl_m51CA9E517679109254D2D3A1D621BB9AE13AF6CE,
	CP875_GetByteCount_m16FE89DA644E0560CA567333DA197DEFE6F7D4AB,
	CP875_ToBytes_m19DA22B375D56C6DBFEFBF1133BFECB5BD7C75D5,
	CP875_GetBytesImpl_m7B663B15464BE8503DE366D40C3D0BDF1404F001,
	CP875__cctor_mD3FFDA27E8FDE077AF09C0DA00C23B97C750474F,
	ENCibm875__ctor_m87AF81CCFD5FD3F8A05B8AAE05FAA3B3D84338CD,
};
static const int32_t s_InvokerIndices[259] = 
{
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
	23,
	601,
	123,
	1943,
	603,
	3,
	23,
};
extern const Il2CppCodeGenModule g_I18N_RareCodeGenModule;
const Il2CppCodeGenModule g_I18N_RareCodeGenModule = 
{
	"I18N.Rare.dll",
	259,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
