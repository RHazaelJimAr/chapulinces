﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void System.Configuration.ConfigurationSection::DeserializeSection(System.Xml.XmlReader)
extern void ConfigurationSection_DeserializeSection_mC39769C65F7E36F2B33E155B4D8ACADB83377B5F (void);
// 0x00000002 System.Boolean System.Configuration.ConfigurationSection::IsModified()
extern void ConfigurationSection_IsModified_mDD7D74427E761D9EFAA2629FE71DD83A8B7D1785 (void);
// 0x00000003 System.Void System.Configuration.ConfigurationSection::ResetModified()
extern void ConfigurationSection_ResetModified_mCA8B3DE0DE1903CDB60E70517BEBD92A06C647E4 (void);
// 0x00000004 System.String System.Configuration.ConfigurationSection::SerializeSection(System.Configuration.ConfigurationElement,System.String,System.Configuration.ConfigurationSaveMode)
extern void ConfigurationSection_SerializeSection_m76F991963602BC728C4B22044ED618A42FA3C3E5 (void);
// 0x00000005 System.Configuration.ConfigurationPropertyCollection System.Configuration.ConfigurationElement::get_Properties()
extern void ConfigurationElement_get_Properties_mB1F40F2F14D68682556E31C36BEF7B62067C9E98 (void);
// 0x00000006 System.Boolean System.Configuration.ConfigurationElement::IsModified()
extern void ConfigurationElement_IsModified_mA046D03044CDCD875C22E34247CE15E7BBC883A5 (void);
// 0x00000007 System.Void System.Configuration.ConfigurationElement::Reset(System.Configuration.ConfigurationElement)
extern void ConfigurationElement_Reset_m39498D76FA0912DA725E3224537BBF7FA5B0FC1A (void);
// 0x00000008 System.Void System.Configuration.ConfigurationElement::ResetModified()
extern void ConfigurationElement_ResetModified_m6AAF1F8A88CEF6F993A6666E3B4D4B2456024989 (void);
// 0x00000009 System.Void System.Configuration.ConfigurationCollectionAttribute::.ctor(System.Type)
extern void ConfigurationCollectionAttribute__ctor_mF41393517164A49C3127C24B1CCBBA3CCBC44A65 (void);
// 0x0000000A System.Void System.Configuration.IgnoreSection::.ctor()
extern void IgnoreSection__ctor_m30C69267DD27E85879BA3AE28ABCDAE783B28350 (void);
// 0x0000000B System.Configuration.ConfigurationPropertyCollection System.Configuration.IgnoreSection::get_Properties()
extern void IgnoreSection_get_Properties_m654A228B012E724695AFD79627F13FCF739244E4 (void);
// 0x0000000C System.Void System.Configuration.IgnoreSection::DeserializeSection(System.Xml.XmlReader)
extern void IgnoreSection_DeserializeSection_mD4D92311BEF0747F961B3E11BFDC13B56052A0EC (void);
// 0x0000000D System.Boolean System.Configuration.IgnoreSection::IsModified()
extern void IgnoreSection_IsModified_m0430C7830B3A902BCAE985427CB2FCE1F15EB595 (void);
// 0x0000000E System.Void System.Configuration.IgnoreSection::Reset(System.Configuration.ConfigurationElement)
extern void IgnoreSection_Reset_m46C76CCBADF508876E17A2A59778E427E20B7628 (void);
// 0x0000000F System.Void System.Configuration.IgnoreSection::ResetModified()
extern void IgnoreSection_ResetModified_mE7AEAA166BBA055767C5AFA05C9F223E1D0FB070 (void);
// 0x00000010 System.String System.Configuration.IgnoreSection::SerializeSection(System.Configuration.ConfigurationElement,System.String,System.Configuration.ConfigurationSaveMode)
extern void IgnoreSection_SerializeSection_m03CB506F46AEA369F5FCAEC048509461D907FEE9 (void);
// 0x00000011 System.Void Unity.ThrowStub::ThrowNotSupportedException()
extern void ThrowStub_ThrowNotSupportedException_mF0DAFE591641D359313AB87E6900E4B05E42390A (void);
static Il2CppMethodPointer s_methodPointers[17] = 
{
	ConfigurationSection_DeserializeSection_mC39769C65F7E36F2B33E155B4D8ACADB83377B5F,
	ConfigurationSection_IsModified_mDD7D74427E761D9EFAA2629FE71DD83A8B7D1785,
	ConfigurationSection_ResetModified_mCA8B3DE0DE1903CDB60E70517BEBD92A06C647E4,
	ConfigurationSection_SerializeSection_m76F991963602BC728C4B22044ED618A42FA3C3E5,
	ConfigurationElement_get_Properties_mB1F40F2F14D68682556E31C36BEF7B62067C9E98,
	ConfigurationElement_IsModified_mA046D03044CDCD875C22E34247CE15E7BBC883A5,
	ConfigurationElement_Reset_m39498D76FA0912DA725E3224537BBF7FA5B0FC1A,
	ConfigurationElement_ResetModified_m6AAF1F8A88CEF6F993A6666E3B4D4B2456024989,
	ConfigurationCollectionAttribute__ctor_mF41393517164A49C3127C24B1CCBBA3CCBC44A65,
	IgnoreSection__ctor_m30C69267DD27E85879BA3AE28ABCDAE783B28350,
	IgnoreSection_get_Properties_m654A228B012E724695AFD79627F13FCF739244E4,
	IgnoreSection_DeserializeSection_mD4D92311BEF0747F961B3E11BFDC13B56052A0EC,
	IgnoreSection_IsModified_m0430C7830B3A902BCAE985427CB2FCE1F15EB595,
	IgnoreSection_Reset_m46C76CCBADF508876E17A2A59778E427E20B7628,
	IgnoreSection_ResetModified_mE7AEAA166BBA055767C5AFA05C9F223E1D0FB070,
	IgnoreSection_SerializeSection_m03CB506F46AEA369F5FCAEC048509461D907FEE9,
	ThrowStub_ThrowNotSupportedException_mF0DAFE591641D359313AB87E6900E4B05E42390A,
};
static const int32_t s_InvokerIndices[17] = 
{
	26,
	95,
	23,
	472,
	14,
	95,
	26,
	23,
	26,
	23,
	14,
	26,
	95,
	26,
	23,
	472,
	3,
};
extern const Il2CppCodeGenModule g_System_ConfigurationCodeGenModule;
const Il2CppCodeGenModule g_System_ConfigurationCodeGenModule = 
{
	"System.Configuration.dll",
	17,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
