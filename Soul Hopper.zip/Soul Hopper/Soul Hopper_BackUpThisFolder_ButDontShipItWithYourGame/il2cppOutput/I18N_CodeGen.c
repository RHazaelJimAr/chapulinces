﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void I18N.Common.ByteEncoding::.ctor(System.Int32,System.Char[],System.String,System.String,System.String,System.String,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32)
extern void ByteEncoding__ctor_m8DAEFF4098B9FF03A6A7B14C51699EB6CEA11928 (void);
// 0x00000002 System.Boolean I18N.Common.ByteEncoding::IsAlwaysNormalized(System.Text.NormalizationForm)
extern void ByteEncoding_IsAlwaysNormalized_m2E933AC2BBBF9D676EBABE209130607839E197D8 (void);
// 0x00000003 System.Boolean I18N.Common.ByteEncoding::get_IsSingleByte()
extern void ByteEncoding_get_IsSingleByte_m851583D3C3033B6DA87A971177E97553317803AF (void);
// 0x00000004 System.Int32 I18N.Common.ByteEncoding::GetByteCount(System.String)
extern void ByteEncoding_GetByteCount_m53EA1506E7E68BF1E51C291257FBE7B3106DD480 (void);
// 0x00000005 System.Int32 I18N.Common.ByteEncoding::GetByteCountImpl(System.Char*,System.Int32)
extern void ByteEncoding_GetByteCountImpl_mFB7D4C2294C5F3EA1F98897C1A237DD9CFE447B1 (void);
// 0x00000006 System.Void I18N.Common.ByteEncoding::ToBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
// 0x00000007 System.Void I18N.Common.ByteEncoding::ToBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteEncoding_ToBytes_m2E0E80AE53BB077498625D75659E6D22FA791976 (void);
// 0x00000008 System.Int32 I18N.Common.ByteEncoding::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void ByteEncoding_GetBytesImpl_mDC44F53A9FFB19B208AB760FBB9866C03945B8B1 (void);
// 0x00000009 System.Int32 I18N.Common.ByteEncoding::GetCharCount(System.Byte[],System.Int32,System.Int32)
extern void ByteEncoding_GetCharCount_mE9B907CBD7D7CBEF50E0905BFD373C5D14027282 (void);
// 0x0000000A System.Int32 I18N.Common.ByteEncoding::GetChars(System.Byte[],System.Int32,System.Int32,System.Char[],System.Int32)
extern void ByteEncoding_GetChars_mAA72EBDC618333ED109C36B68FC5268F34C45E48 (void);
// 0x0000000B System.Int32 I18N.Common.ByteEncoding::GetMaxByteCount(System.Int32)
extern void ByteEncoding_GetMaxByteCount_m4959DB95E37FDE25392EF2D8BBF0AF6E134B906D (void);
// 0x0000000C System.Int32 I18N.Common.ByteEncoding::GetMaxCharCount(System.Int32)
extern void ByteEncoding_GetMaxCharCount_mB5CA001E872D5BCC7A5C02645BD2669B6676A037 (void);
// 0x0000000D System.String I18N.Common.ByteEncoding::GetString(System.Byte[],System.Int32,System.Int32)
extern void ByteEncoding_GetString_m56623D49895C437BEBECCE3D75332995DAB5E5A9 (void);
// 0x0000000E System.String I18N.Common.ByteEncoding::GetString(System.Byte[])
extern void ByteEncoding_GetString_m370BA826BC65653CE503BA32F7372944989510BE (void);
// 0x0000000F System.String I18N.Common.ByteEncoding::get_BodyName()
extern void ByteEncoding_get_BodyName_m28E236CBF3E8998FD0FDD43C126919FACBF256C9 (void);
// 0x00000010 System.String I18N.Common.ByteEncoding::get_EncodingName()
extern void ByteEncoding_get_EncodingName_mEC649C9EC3DE76E890A69FDCAA56E917EF45B737 (void);
// 0x00000011 System.String I18N.Common.ByteEncoding::get_HeaderName()
extern void ByteEncoding_get_HeaderName_m59E35ECDF19E8020564666F8B7EBCAB39E1202BB (void);
// 0x00000012 System.Boolean I18N.Common.ByteEncoding::get_IsBrowserDisplay()
extern void ByteEncoding_get_IsBrowserDisplay_m3E8862C0FC58D672B5715A3496CA36D2607C2EF7 (void);
// 0x00000013 System.Boolean I18N.Common.ByteEncoding::get_IsBrowserSave()
extern void ByteEncoding_get_IsBrowserSave_m4002CFC12E500968EC9659499CF3EC186C53622A (void);
// 0x00000014 System.Boolean I18N.Common.ByteEncoding::get_IsMailNewsDisplay()
extern void ByteEncoding_get_IsMailNewsDisplay_m9A3B28D9D31E4E8FE1A25C30C87D7CD1A05E5999 (void);
// 0x00000015 System.Boolean I18N.Common.ByteEncoding::get_IsMailNewsSave()
extern void ByteEncoding_get_IsMailNewsSave_mAAF0545D0B74918B4831810FA547A823EBE0C73E (void);
// 0x00000016 System.String I18N.Common.ByteEncoding::get_WebName()
extern void ByteEncoding_get_WebName_mFD42B8741BDCF5BC7AF46E36B6CE387CFA281CB8 (void);
// 0x00000017 System.Int32 I18N.Common.ByteEncoding::get_WindowsCodePage()
extern void ByteEncoding_get_WindowsCodePage_m403C809C6E9AE110932FFC1916280E917CE82404 (void);
// 0x00000018 System.Void I18N.Common.ByteSafeEncoding::.ctor(System.Int32,System.Char[],System.String,System.String,System.String,System.String,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32)
extern void ByteSafeEncoding__ctor_m6694BB05F26ADA7F780DE5F50C0B8296DC4FE889 (void);
// 0x00000019 System.Boolean I18N.Common.ByteSafeEncoding::IsAlwaysNormalized(System.Text.NormalizationForm)
extern void ByteSafeEncoding_IsAlwaysNormalized_m9C6EA89DC627879384B47CD9C1A9399968666AB8 (void);
// 0x0000001A System.Boolean I18N.Common.ByteSafeEncoding::get_IsSingleByte()
extern void ByteSafeEncoding_get_IsSingleByte_m242EFC4BBBFE5249F9B32045033BEFF1B5D23A83 (void);
// 0x0000001B System.Int32 I18N.Common.ByteSafeEncoding::GetByteCount(System.String)
extern void ByteSafeEncoding_GetByteCount_mEDDAD01B58586E0C5EEB9706278A74A54CF4514B (void);
// 0x0000001C System.Int32 I18N.Common.ByteSafeEncoding::GetByteCount(System.Char[],System.Int32,System.Int32)
extern void ByteSafeEncoding_GetByteCount_m9AA0760CE8AFD451B64469857C47928EF0278A91 (void);
// 0x0000001D System.Int32 I18N.Common.ByteSafeEncoding::GetByteCount(System.Char*,System.Int32)
extern void ByteSafeEncoding_GetByteCount_m5A3BAD4ED51833B4AA86E8C7CC689D3B9B3AD3D4 (void);
// 0x0000001E System.Void I18N.Common.ByteSafeEncoding::ToBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
// 0x0000001F System.Void I18N.Common.ByteSafeEncoding::ToBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteSafeEncoding_ToBytes_m3A290D3C8156AF542928B8B561BFDAFA474A3C39 (void);
// 0x00000020 System.Int32 I18N.Common.ByteSafeEncoding::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteSafeEncoding_GetBytes_mE4D32EFB95B8CD346A0AC55B3532FD5C5DDE13FA (void);
// 0x00000021 System.Int32 I18N.Common.ByteSafeEncoding::GetBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ByteSafeEncoding_GetBytes_mE7441F3C608CEBAE19E151B25CDB1CDA84163895 (void);
// 0x00000022 System.Byte[] I18N.Common.ByteSafeEncoding::GetBytes(System.String)
extern void ByteSafeEncoding_GetBytes_mBAB7B32E1153F6BEBFDC8EA82D8C887244CFE5C6 (void);
// 0x00000023 System.Int32 I18N.Common.ByteSafeEncoding::GetCharCount(System.Byte[],System.Int32,System.Int32)
extern void ByteSafeEncoding_GetCharCount_m21934970FEB2147A14476D1BEAE46A50A1DF7BE2 (void);
// 0x00000024 System.Int32 I18N.Common.ByteSafeEncoding::GetChars(System.Byte[],System.Int32,System.Int32,System.Char[],System.Int32)
extern void ByteSafeEncoding_GetChars_m954395A86CA621A4E6252EEEC930FAF4E0FE0558 (void);
// 0x00000025 System.Int32 I18N.Common.ByteSafeEncoding::GetMaxByteCount(System.Int32)
extern void ByteSafeEncoding_GetMaxByteCount_m699DA4681F7256F9377A78AF6706650DD4FD27AF (void);
// 0x00000026 System.Int32 I18N.Common.ByteSafeEncoding::GetMaxCharCount(System.Int32)
extern void ByteSafeEncoding_GetMaxCharCount_mC21230B957FD7121168AFB23B72B6A2B3392F069 (void);
// 0x00000027 System.String I18N.Common.ByteSafeEncoding::GetString(System.Byte[],System.Int32,System.Int32)
extern void ByteSafeEncoding_GetString_mBE8E256C770E8C1AB5F478C44D8B319041AF2B7D (void);
// 0x00000028 System.String I18N.Common.ByteSafeEncoding::GetString(System.Byte[])
extern void ByteSafeEncoding_GetString_m05FF3E544344837843E6E45C08D654CA60E4E80A (void);
// 0x00000029 System.String I18N.Common.ByteSafeEncoding::get_BodyName()
extern void ByteSafeEncoding_get_BodyName_m21CA06AE97DFB2031722D4DF63F21DCA6374A0FD (void);
// 0x0000002A System.String I18N.Common.ByteSafeEncoding::get_EncodingName()
extern void ByteSafeEncoding_get_EncodingName_m5255390A28175CE232A0964D5C775A604D6D166A (void);
// 0x0000002B System.String I18N.Common.ByteSafeEncoding::get_HeaderName()
extern void ByteSafeEncoding_get_HeaderName_mF5461F4E9D096048F01B6B9FD5A86725E2C0B88C (void);
// 0x0000002C System.Boolean I18N.Common.ByteSafeEncoding::get_IsBrowserDisplay()
extern void ByteSafeEncoding_get_IsBrowserDisplay_m3E37104FEF25424EE18744D02CF68F208D45E000 (void);
// 0x0000002D System.Boolean I18N.Common.ByteSafeEncoding::get_IsBrowserSave()
extern void ByteSafeEncoding_get_IsBrowserSave_mA995BDB7644B15D9A7F5723752DC80FCE4732EFE (void);
// 0x0000002E System.Boolean I18N.Common.ByteSafeEncoding::get_IsMailNewsDisplay()
extern void ByteSafeEncoding_get_IsMailNewsDisplay_mD64294995D9357A4E9C0E9BB09ABFE74E80347F1 (void);
// 0x0000002F System.Boolean I18N.Common.ByteSafeEncoding::get_IsMailNewsSave()
extern void ByteSafeEncoding_get_IsMailNewsSave_mBF385E51EAFD10FA0878D7753D4AD53E4583DBC4 (void);
// 0x00000030 System.String I18N.Common.ByteSafeEncoding::get_WebName()
extern void ByteSafeEncoding_get_WebName_m998BA57F31CC221F2FBD7E63CFCE02FB679C9586 (void);
// 0x00000031 System.Int32 I18N.Common.ByteSafeEncoding::get_WindowsCodePage()
extern void ByteSafeEncoding_get_WindowsCodePage_mC25F965C408578B88FC22DE8C900B2B3B3E4BADD (void);
// 0x00000032 System.Void I18N.Common.ReferenceSourceDefaultEncoder::.ctor(System.Text.Encoding)
extern void ReferenceSourceDefaultEncoder__ctor_m8D98EE3F5CA918926CB998428AF21CBC5711A878 (void);
// 0x00000033 System.Void I18N.Common.ReferenceSourceDefaultEncoder::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void ReferenceSourceDefaultEncoder__ctor_mE817E029A8E3B4FBF5DE3B2C2C272C26E6620D23 (void);
// 0x00000034 System.Object I18N.Common.ReferenceSourceDefaultEncoder::GetRealObject(System.Runtime.Serialization.StreamingContext)
extern void ReferenceSourceDefaultEncoder_GetRealObject_m75ECE546BB38C07FDC2DFFBB5DBA0A8076E711A0 (void);
// 0x00000035 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetByteCount(System.Char[],System.Int32,System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetByteCount_m9278A6754651C0B3AECB606C9C6DA8B316B94587 (void);
// 0x00000036 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetByteCount(System.Char*,System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetByteCount_m212CF6FDA99A98577B8EA017F8F4C18C767E1286 (void);
// 0x00000037 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetBytes_m210D6EBC84AF6B04C14CC03D232CB817AE691BB8 (void);
// 0x00000038 System.Int32 I18N.Common.ReferenceSourceDefaultEncoder::GetBytes(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean)
extern void ReferenceSourceDefaultEncoder_GetBytes_m8B3E6AAD6AC085D6DAEE920541B1D2C321FD1AAF (void);
// 0x00000039 System.String I18N.Common.Handlers::GetAlias(System.String)
extern void Handlers_GetAlias_m1EF1702DF81339BF115B315C188A66C63720C69E (void);
// 0x0000003A System.Void I18N.Common.Handlers::BuildHash()
extern void Handlers_BuildHash_m644802A2D6689C19E087FD2168FB3CE80375B761 (void);
// 0x0000003B System.Void I18N.Common.Handlers::.ctor()
extern void Handlers__ctor_mA312F21494886A6C4F5489765BFE16EE1022FD82 (void);
// 0x0000003C System.Void I18N.Common.Handlers::.cctor()
extern void Handlers__cctor_mD7AF906EDBC706FBEFE93041087E5F522152C5D9 (void);
// 0x0000003D System.Void I18N.Common.Manager::.ctor()
extern void Manager__ctor_m7D3D7318300FF1F3346B1DB7040C9ACA6878B218 (void);
// 0x0000003E I18N.Common.Manager I18N.Common.Manager::get_PrimaryManager()
extern void Manager_get_PrimaryManager_m70D71D7FAD2DF21C1E9231D3004A1A75F3CECA5F (void);
// 0x0000003F System.String I18N.Common.Manager::Normalize(System.String)
extern void Manager_Normalize_m35FAF8D4D5146882E4A6626775AF69B73DFAC3B5 (void);
// 0x00000040 System.Text.Encoding I18N.Common.Manager::GetEncoding(System.Int32)
extern void Manager_GetEncoding_m84CBAFE26AC75B334FEDC1E4E4B6498FC0E509F5 (void);
// 0x00000041 System.Text.Encoding I18N.Common.Manager::GetEncoding(System.String)
extern void Manager_GetEncoding_m6E0B539812A4B7FC0DFB3E54F9FD801E51491959 (void);
// 0x00000042 System.Globalization.CultureInfo I18N.Common.Manager::GetCulture(System.Int32,System.Boolean)
extern void Manager_GetCulture_m4168CE3DC238BAECFDAB2C3204DB3B979F5AAE48 (void);
// 0x00000043 System.Globalization.CultureInfo I18N.Common.Manager::GetCulture(System.String,System.Boolean)
extern void Manager_GetCulture_m228304BACB1350DC578871CA107A1F3D4F8634F7 (void);
// 0x00000044 System.Object I18N.Common.Manager::Instantiate(System.String)
extern void Manager_Instantiate_mB997538122BB4AAB5B34755EE49ED1470A28F88C (void);
// 0x00000045 System.Void I18N.Common.Manager::LoadClassList()
extern void Manager_LoadClassList_m79D2A344E0D6DED84D55E557CC1C9978655594F2 (void);
// 0x00000046 System.Void I18N.Common.Manager::LoadInternalClasses()
extern void Manager_LoadInternalClasses_m0609061DA0905689292597CE3E25DE290F53F6BC (void);
// 0x00000047 System.Void I18N.Common.Manager::.cctor()
extern void Manager__cctor_mD8383C649D396B711503269D50BB10864B44130B (void);
// 0x00000048 System.Void I18N.Common.MonoEncoding::.ctor(System.Int32)
extern void MonoEncoding__ctor_m427A6A8025BFA268D02445087C672A5712C9F3B6 (void);
// 0x00000049 System.Void I18N.Common.MonoEncoding::.ctor(System.Int32,System.Int32)
extern void MonoEncoding__ctor_mE0CFEC47068512B56389DCE6FBAB34F1698B320C (void);
// 0x0000004A System.Int32 I18N.Common.MonoEncoding::get_WindowsCodePage()
extern void MonoEncoding_get_WindowsCodePage_m6205E7BD1AD719072C5FB52CDDDA003722989969 (void);
// 0x0000004B System.Int32 I18N.Common.MonoEncoding::GetBytesInternal(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean,System.Object)
extern void MonoEncoding_GetBytesInternal_m472FFFDC456BF11F597B9897933DE97588B09A82 (void);
// 0x0000004C System.Void I18N.Common.MonoEncoding::HandleFallback(System.Text.EncoderFallbackBuffer&,System.Char*,System.Int32&,System.Int32&,System.Byte*,System.Int32&,System.Int32&,System.Object)
extern void MonoEncoding_HandleFallback_mF72E24BEA9BAE0E4E66DAC63D63563E50E562136 (void);
// 0x0000004D System.Void I18N.Common.MonoEncoding::HandleFallback(System.Text.EncoderFallbackBuffer&,System.Char*,System.Int32&,System.Int32&,System.Byte*,System.Int32&,System.Int32&)
extern void MonoEncoding_HandleFallback_m5FDF88A9F1E1E1826BF59F97065C7D503BF2EB4F (void);
// 0x0000004E System.Int32 I18N.Common.MonoEncoding::GetByteCount(System.Char[],System.Int32,System.Int32)
extern void MonoEncoding_GetByteCount_m4B10378E85EB8711A96F4ACFCC8D94BEA33EBEE1 (void);
// 0x0000004F System.Int32 I18N.Common.MonoEncoding::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void MonoEncoding_GetBytes_mCCA96622B176F4AA3F8CD991319B84521A020F27 (void);
// 0x00000050 System.Int32 I18N.Common.MonoEncoding::GetBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32)
extern void MonoEncoding_GetBytes_m2C241EDDCA5F07746301C65DFB1CE856BCAFF857 (void);
// 0x00000051 System.Int32 I18N.Common.MonoEncoding::GetByteCount(System.Char*,System.Int32)
extern void MonoEncoding_GetByteCount_mDFA02AA1CB9841AD3926C73D120B3C14A45CE6ED (void);
// 0x00000052 System.Int32 I18N.Common.MonoEncoding::GetBytes(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void MonoEncoding_GetBytes_m435A8F1159888B3AE6471F6305D7650CE69A16E2 (void);
// 0x00000053 System.Int32 I18N.Common.MonoEncoding::GetByteCountImpl(System.Char*,System.Int32)
// 0x00000054 System.Int32 I18N.Common.MonoEncoding::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32)
// 0x00000055 System.Text.Encoder I18N.Common.MonoEncoding::GetEncoder()
extern void MonoEncoding_GetEncoder_m2487C20D7BEAF16FF849A95F3B767CF4839EA52C (void);
// 0x00000056 System.Void I18N.Common.MonoEncoder::.ctor(I18N.Common.MonoEncoding)
extern void MonoEncoder__ctor_m4A9E825EE34E75629BB1F4F25033449360549988 (void);
// 0x00000057 System.Int32 I18N.Common.MonoEncoder::GetByteCount(System.Char[],System.Int32,System.Int32,System.Boolean)
extern void MonoEncoder_GetByteCount_mA898844D85B679B39B4F497FFD8762A127E5739A (void);
// 0x00000058 System.Int32 I18N.Common.MonoEncoder::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Boolean)
extern void MonoEncoder_GetBytes_mFFE524609262FB9FEBA38C38D7EC2A411F941F38 (void);
// 0x00000059 System.Int32 I18N.Common.MonoEncoder::GetByteCountImpl(System.Char*,System.Int32,System.Boolean)
// 0x0000005A System.Int32 I18N.Common.MonoEncoder::GetBytesImpl(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean)
// 0x0000005B System.Int32 I18N.Common.MonoEncoder::GetBytes(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean)
extern void MonoEncoder_GetBytes_m6030A2D50740A0CACCF84B21A9F14E7972C186E7 (void);
// 0x0000005C System.Void I18N.Common.MonoEncoder::HandleFallback(System.Char*,System.Int32&,System.Int32&,System.Byte*,System.Int32&,System.Int32&,System.Object)
extern void MonoEncoder_HandleFallback_mECF8365417EE44272EDDF39DDDC491CB27A3EA1D (void);
// 0x0000005D System.Void I18N.Common.MonoEncodingDefaultEncoder::.ctor(System.Text.Encoding)
extern void MonoEncodingDefaultEncoder__ctor_m0199556F330303CF120F0082E226937554D3B745 (void);
// 0x0000005E System.Void I18N.Common.MonoEncodingDefaultEncoder::Convert(System.Char*,System.Int32,System.Byte*,System.Int32,System.Boolean,System.Int32&,System.Int32&,System.Boolean&)
extern void MonoEncodingDefaultEncoder_Convert_m4DC710EA6DA800D8BB70280B467FD171C11074C8 (void);
// 0x0000005F System.Void I18N.Common.MonoEncodingDefaultEncoder::Convert(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32,System.Boolean,System.Int32&,System.Int32&,System.Boolean&)
extern void MonoEncodingDefaultEncoder_Convert_m4F0E4CEF5E96715618FB9A8373C204F967F1D383 (void);
// 0x00000060 System.Void I18N.Common.MonoEncodingDefaultEncoder::CheckArguments(System.Char*,System.Int32,System.Byte*,System.Int32)
extern void MonoEncodingDefaultEncoder_CheckArguments_mCDCF4070F7CB4EEF0A2577570D231E8C3092B362 (void);
// 0x00000061 System.Void I18N.Common.MonoSafeEncoding::.ctor(System.Int32)
extern void MonoSafeEncoding__ctor_mEB980CDD792FF55EA55FE6958843A597E37BFE54 (void);
// 0x00000062 System.Void I18N.Common.MonoSafeEncoding::.ctor(System.Int32,System.Int32)
extern void MonoSafeEncoding__ctor_m4EDE3B0152D4E696F9EDB1C7C6DB9B0D2AB57213 (void);
// 0x00000063 System.Int32 I18N.Common.MonoSafeEncoding::get_WindowsCodePage()
extern void MonoSafeEncoding_get_WindowsCodePage_m1016E362F33D644982172BF602C36BD2A00AC12F (void);
// 0x00000064 System.Int32 I18N.Common.MonoSafeEncoding::GetBytesInternal(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Boolean,System.Object)
extern void MonoSafeEncoding_GetBytesInternal_mB37FEA816580DF7EE9773B31EC26C4DE698C0832 (void);
// 0x00000065 System.Void I18N.Common.MonoSafeEncoding::HandleFallback(System.Text.EncoderFallbackBuffer&,System.Char[],System.Int32&,System.Int32&,System.Byte[],System.Int32&,System.Int32&,System.Object)
extern void MonoSafeEncoding_HandleFallback_m8F545C673F25A17064F9CE887DD2C8101BF05A31 (void);
// 0x00000066 System.Void I18N.Common.MonoSafeEncoder::.ctor(I18N.Common.MonoSafeEncoding)
extern void MonoSafeEncoder__ctor_mDDF806CF1F27586807407514DDF17F67A0DF102F (void);
// 0x00000067 System.Void I18N.Common.MonoSafeEncoder::HandleFallback(System.Char[],System.Int32&,System.Int32&,System.Byte[],System.Int32&,System.Int32&,System.Object)
extern void MonoSafeEncoder_HandleFallback_m2766944FE2E94701AFF74BA673D9E3C05DEFBE10 (void);
// 0x00000068 System.String I18N.Common.Strings::GetString(System.String)
extern void Strings_GetString_mC12AE3CBC17C1E3463EF669D9C84059E611A9BFA (void);
// 0x00000069 System.Void I18N.Common.Strings::.ctor()
extern void Strings__ctor_mCAC274B1CFBF95C2B66288607299F4C833105B4B (void);
static Il2CppMethodPointer s_methodPointers[105] = 
{
	ByteEncoding__ctor_m8DAEFF4098B9FF03A6A7B14C51699EB6CEA11928,
	ByteEncoding_IsAlwaysNormalized_m2E933AC2BBBF9D676EBABE209130607839E197D8,
	ByteEncoding_get_IsSingleByte_m851583D3C3033B6DA87A971177E97553317803AF,
	ByteEncoding_GetByteCount_m53EA1506E7E68BF1E51C291257FBE7B3106DD480,
	ByteEncoding_GetByteCountImpl_mFB7D4C2294C5F3EA1F98897C1A237DD9CFE447B1,
	NULL,
	ByteEncoding_ToBytes_m2E0E80AE53BB077498625D75659E6D22FA791976,
	ByteEncoding_GetBytesImpl_mDC44F53A9FFB19B208AB760FBB9866C03945B8B1,
	ByteEncoding_GetCharCount_mE9B907CBD7D7CBEF50E0905BFD373C5D14027282,
	ByteEncoding_GetChars_mAA72EBDC618333ED109C36B68FC5268F34C45E48,
	ByteEncoding_GetMaxByteCount_m4959DB95E37FDE25392EF2D8BBF0AF6E134B906D,
	ByteEncoding_GetMaxCharCount_mB5CA001E872D5BCC7A5C02645BD2669B6676A037,
	ByteEncoding_GetString_m56623D49895C437BEBECCE3D75332995DAB5E5A9,
	ByteEncoding_GetString_m370BA826BC65653CE503BA32F7372944989510BE,
	ByteEncoding_get_BodyName_m28E236CBF3E8998FD0FDD43C126919FACBF256C9,
	ByteEncoding_get_EncodingName_mEC649C9EC3DE76E890A69FDCAA56E917EF45B737,
	ByteEncoding_get_HeaderName_m59E35ECDF19E8020564666F8B7EBCAB39E1202BB,
	ByteEncoding_get_IsBrowserDisplay_m3E8862C0FC58D672B5715A3496CA36D2607C2EF7,
	ByteEncoding_get_IsBrowserSave_m4002CFC12E500968EC9659499CF3EC186C53622A,
	ByteEncoding_get_IsMailNewsDisplay_m9A3B28D9D31E4E8FE1A25C30C87D7CD1A05E5999,
	ByteEncoding_get_IsMailNewsSave_mAAF0545D0B74918B4831810FA547A823EBE0C73E,
	ByteEncoding_get_WebName_mFD42B8741BDCF5BC7AF46E36B6CE387CFA281CB8,
	ByteEncoding_get_WindowsCodePage_m403C809C6E9AE110932FFC1916280E917CE82404,
	ByteSafeEncoding__ctor_m6694BB05F26ADA7F780DE5F50C0B8296DC4FE889,
	ByteSafeEncoding_IsAlwaysNormalized_m9C6EA89DC627879384B47CD9C1A9399968666AB8,
	ByteSafeEncoding_get_IsSingleByte_m242EFC4BBBFE5249F9B32045033BEFF1B5D23A83,
	ByteSafeEncoding_GetByteCount_mEDDAD01B58586E0C5EEB9706278A74A54CF4514B,
	ByteSafeEncoding_GetByteCount_m9AA0760CE8AFD451B64469857C47928EF0278A91,
	ByteSafeEncoding_GetByteCount_m5A3BAD4ED51833B4AA86E8C7CC689D3B9B3AD3D4,
	NULL,
	ByteSafeEncoding_ToBytes_m3A290D3C8156AF542928B8B561BFDAFA474A3C39,
	ByteSafeEncoding_GetBytes_mE4D32EFB95B8CD346A0AC55B3532FD5C5DDE13FA,
	ByteSafeEncoding_GetBytes_mE7441F3C608CEBAE19E151B25CDB1CDA84163895,
	ByteSafeEncoding_GetBytes_mBAB7B32E1153F6BEBFDC8EA82D8C887244CFE5C6,
	ByteSafeEncoding_GetCharCount_m21934970FEB2147A14476D1BEAE46A50A1DF7BE2,
	ByteSafeEncoding_GetChars_m954395A86CA621A4E6252EEEC930FAF4E0FE0558,
	ByteSafeEncoding_GetMaxByteCount_m699DA4681F7256F9377A78AF6706650DD4FD27AF,
	ByteSafeEncoding_GetMaxCharCount_mC21230B957FD7121168AFB23B72B6A2B3392F069,
	ByteSafeEncoding_GetString_mBE8E256C770E8C1AB5F478C44D8B319041AF2B7D,
	ByteSafeEncoding_GetString_m05FF3E544344837843E6E45C08D654CA60E4E80A,
	ByteSafeEncoding_get_BodyName_m21CA06AE97DFB2031722D4DF63F21DCA6374A0FD,
	ByteSafeEncoding_get_EncodingName_m5255390A28175CE232A0964D5C775A604D6D166A,
	ByteSafeEncoding_get_HeaderName_mF5461F4E9D096048F01B6B9FD5A86725E2C0B88C,
	ByteSafeEncoding_get_IsBrowserDisplay_m3E37104FEF25424EE18744D02CF68F208D45E000,
	ByteSafeEncoding_get_IsBrowserSave_mA995BDB7644B15D9A7F5723752DC80FCE4732EFE,
	ByteSafeEncoding_get_IsMailNewsDisplay_mD64294995D9357A4E9C0E9BB09ABFE74E80347F1,
	ByteSafeEncoding_get_IsMailNewsSave_mBF385E51EAFD10FA0878D7753D4AD53E4583DBC4,
	ByteSafeEncoding_get_WebName_m998BA57F31CC221F2FBD7E63CFCE02FB679C9586,
	ByteSafeEncoding_get_WindowsCodePage_mC25F965C408578B88FC22DE8C900B2B3B3E4BADD,
	ReferenceSourceDefaultEncoder__ctor_m8D98EE3F5CA918926CB998428AF21CBC5711A878,
	ReferenceSourceDefaultEncoder__ctor_mE817E029A8E3B4FBF5DE3B2C2C272C26E6620D23,
	ReferenceSourceDefaultEncoder_GetRealObject_m75ECE546BB38C07FDC2DFFBB5DBA0A8076E711A0,
	ReferenceSourceDefaultEncoder_GetByteCount_m9278A6754651C0B3AECB606C9C6DA8B316B94587,
	ReferenceSourceDefaultEncoder_GetByteCount_m212CF6FDA99A98577B8EA017F8F4C18C767E1286,
	ReferenceSourceDefaultEncoder_GetBytes_m210D6EBC84AF6B04C14CC03D232CB817AE691BB8,
	ReferenceSourceDefaultEncoder_GetBytes_m8B3E6AAD6AC085D6DAEE920541B1D2C321FD1AAF,
	Handlers_GetAlias_m1EF1702DF81339BF115B315C188A66C63720C69E,
	Handlers_BuildHash_m644802A2D6689C19E087FD2168FB3CE80375B761,
	Handlers__ctor_mA312F21494886A6C4F5489765BFE16EE1022FD82,
	Handlers__cctor_mD7AF906EDBC706FBEFE93041087E5F522152C5D9,
	Manager__ctor_m7D3D7318300FF1F3346B1DB7040C9ACA6878B218,
	Manager_get_PrimaryManager_m70D71D7FAD2DF21C1E9231D3004A1A75F3CECA5F,
	Manager_Normalize_m35FAF8D4D5146882E4A6626775AF69B73DFAC3B5,
	Manager_GetEncoding_m84CBAFE26AC75B334FEDC1E4E4B6498FC0E509F5,
	Manager_GetEncoding_m6E0B539812A4B7FC0DFB3E54F9FD801E51491959,
	Manager_GetCulture_m4168CE3DC238BAECFDAB2C3204DB3B979F5AAE48,
	Manager_GetCulture_m228304BACB1350DC578871CA107A1F3D4F8634F7,
	Manager_Instantiate_mB997538122BB4AAB5B34755EE49ED1470A28F88C,
	Manager_LoadClassList_m79D2A344E0D6DED84D55E557CC1C9978655594F2,
	Manager_LoadInternalClasses_m0609061DA0905689292597CE3E25DE290F53F6BC,
	Manager__cctor_mD8383C649D396B711503269D50BB10864B44130B,
	MonoEncoding__ctor_m427A6A8025BFA268D02445087C672A5712C9F3B6,
	MonoEncoding__ctor_mE0CFEC47068512B56389DCE6FBAB34F1698B320C,
	MonoEncoding_get_WindowsCodePage_m6205E7BD1AD719072C5FB52CDDDA003722989969,
	MonoEncoding_GetBytesInternal_m472FFFDC456BF11F597B9897933DE97588B09A82,
	MonoEncoding_HandleFallback_mF72E24BEA9BAE0E4E66DAC63D63563E50E562136,
	MonoEncoding_HandleFallback_m5FDF88A9F1E1E1826BF59F97065C7D503BF2EB4F,
	MonoEncoding_GetByteCount_m4B10378E85EB8711A96F4ACFCC8D94BEA33EBEE1,
	MonoEncoding_GetBytes_mCCA96622B176F4AA3F8CD991319B84521A020F27,
	MonoEncoding_GetBytes_m2C241EDDCA5F07746301C65DFB1CE856BCAFF857,
	MonoEncoding_GetByteCount_mDFA02AA1CB9841AD3926C73D120B3C14A45CE6ED,
	MonoEncoding_GetBytes_m435A8F1159888B3AE6471F6305D7650CE69A16E2,
	NULL,
	NULL,
	MonoEncoding_GetEncoder_m2487C20D7BEAF16FF849A95F3B767CF4839EA52C,
	MonoEncoder__ctor_m4A9E825EE34E75629BB1F4F25033449360549988,
	MonoEncoder_GetByteCount_mA898844D85B679B39B4F497FFD8762A127E5739A,
	MonoEncoder_GetBytes_mFFE524609262FB9FEBA38C38D7EC2A411F941F38,
	NULL,
	NULL,
	MonoEncoder_GetBytes_m6030A2D50740A0CACCF84B21A9F14E7972C186E7,
	MonoEncoder_HandleFallback_mECF8365417EE44272EDDF39DDDC491CB27A3EA1D,
	MonoEncodingDefaultEncoder__ctor_m0199556F330303CF120F0082E226937554D3B745,
	MonoEncodingDefaultEncoder_Convert_m4DC710EA6DA800D8BB70280B467FD171C11074C8,
	MonoEncodingDefaultEncoder_Convert_m4F0E4CEF5E96715618FB9A8373C204F967F1D383,
	MonoEncodingDefaultEncoder_CheckArguments_mCDCF4070F7CB4EEF0A2577570D231E8C3092B362,
	MonoSafeEncoding__ctor_mEB980CDD792FF55EA55FE6958843A597E37BFE54,
	MonoSafeEncoding__ctor_m4EDE3B0152D4E696F9EDB1C7C6DB9B0D2AB57213,
	MonoSafeEncoding_get_WindowsCodePage_m1016E362F33D644982172BF602C36BD2A00AC12F,
	MonoSafeEncoding_GetBytesInternal_mB37FEA816580DF7EE9773B31EC26C4DE698C0832,
	MonoSafeEncoding_HandleFallback_m8F545C673F25A17064F9CE887DD2C8101BF05A31,
	MonoSafeEncoder__ctor_mDDF806CF1F27586807407514DDF17F67A0DF102F,
	MonoSafeEncoder_HandleFallback_m2766944FE2E94701AFF74BA673D9E3C05DEFBE10,
	Strings_GetString_mC12AE3CBC17C1E3463EF669D9C84059E611A9BFA,
	Strings__ctor_mCAC274B1CFBF95C2B66288607299F4C833105B4B,
};
static const int32_t s_InvokerIndices[105] = 
{
	1942,
	30,
	95,
	123,
	601,
	1943,
	60,
	603,
	471,
	602,
	37,
	37,
	54,
	28,
	14,
	14,
	14,
	95,
	95,
	95,
	95,
	14,
	10,
	1942,
	30,
	95,
	123,
	471,
	601,
	60,
	60,
	602,
	602,
	28,
	471,
	602,
	37,
	37,
	54,
	28,
	14,
	14,
	14,
	95,
	95,
	95,
	95,
	14,
	10,
	26,
	180,
	537,
	606,
	607,
	608,
	609,
	0,
	3,
	23,
	3,
	23,
	4,
	0,
	34,
	28,
	1177,
	101,
	28,
	23,
	23,
	3,
	32,
	179,
	10,
	1944,
	1945,
	1946,
	471,
	602,
	602,
	601,
	603,
	601,
	603,
	14,
	26,
	606,
	608,
	607,
	609,
	609,
	1947,
	26,
	612,
	611,
	1943,
	32,
	179,
	10,
	1948,
	1949,
	26,
	1950,
	0,
	23,
};
extern const Il2CppCodeGenModule g_I18NCodeGenModule;
const Il2CppCodeGenModule g_I18NCodeGenModule = 
{
	"I18N.dll",
	105,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
